import { useState } from "react";
import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import AppSidebar from "@/components/AppSidebar";
import PlayerControls from "@/components/PlayerControls";
import Home from "@/pages/Home";
import Search from "@/pages/Search";
import Library from "@/pages/Library";
import Recommend from "@/pages/Recommend";
import Curator from "@/pages/Curator";
import Login from "@/pages/Login";
import NotFound from "@/pages/not-found";

// todo: remove mock functionality
const mockCurrentTrack = {
  id: "current",
  title: "Blinding Lights",
  artist: "The Weeknd",
  album: "After Hours",
  albumArt: "https://i.scdn.co/image/ab67616d0000b2738863bc11d2aa12b54f5aeb36",
  duration: 200,
};

const mockPlaylists = [
  { id: "1", name: "Chill Vibes" },
  { id: "2", name: "Workout Mix" },
  { id: "3", name: "Focus Flow" },
];

function AuthenticatedLayout() {
  const [isPlaying, setIsPlaying] = useState(true);
  const [progress, setProgress] = useState(35);
  const [shuffle, setShuffle] = useState(false);
  const [repeat, setRepeat] = useState<"off" | "all" | "one">("off");

  const handleRepeatToggle = () => {
    const states: ("off" | "all" | "one")[] = ["off", "all", "one"];
    const currentIndex = states.indexOf(repeat);
    setRepeat(states[(currentIndex + 1) % 3]);
  };

  const style = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "3rem",
  };

  return (
    <SidebarProvider style={style as React.CSSProperties}>
      <div className="flex h-screen w-full bg-background">
        <AppSidebar
          playlists={mockPlaylists}
          isAuthenticated={true}
          userName="John Doe"
          onLogout={() => console.log("Logout clicked")}
        />
        <div className="flex flex-col flex-1 overflow-hidden">
          <header className="flex items-center gap-2 p-3 border-b border-border">
            <SidebarTrigger data-testid="button-sidebar-toggle" />
          </header>
          <main className="flex-1 overflow-hidden">
            <Switch>
              <Route path="/" component={Home} />
              <Route path="/search" component={Search} />
              <Route path="/library" component={Library} />
              <Route path="/liked" component={Library} />
              <Route path="/recent" component={Home} />
              <Route path="/discover" component={Recommend} />
              <Route path="/recommend" component={Recommend} />
              <Route path="/curator" component={Curator} />
              <Route component={NotFound} />
            </Switch>
          </main>
        </div>
        <PlayerControls
          currentTrack={mockCurrentTrack}
          isPlaying={isPlaying}
          progress={progress}
          shuffle={shuffle}
          repeat={repeat}
          onPlayPause={() => setIsPlaying(!isPlaying)}
          onNext={() => console.log("Next track")}
          onPrevious={() => console.log("Previous track")}
          onSeek={setProgress}
          onShuffleToggle={() => setShuffle(!shuffle)}
          onRepeatToggle={handleRepeatToggle}
        />
      </div>
    </SidebarProvider>
  );
}

function Router() {
  const [isAuthenticated, setIsAuthenticated] = useState(true); // todo: set to false for real auth

  if (!isAuthenticated) {
    return <Login onLogin={() => setIsAuthenticated(true)} />;
  }

  return <AuthenticatedLayout />;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
