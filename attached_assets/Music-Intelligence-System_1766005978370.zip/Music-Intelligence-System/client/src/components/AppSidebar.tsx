import { useLocation, Link } from "wouter";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarSeparator,
} from "@/components/ui/sidebar";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import {
  Home,
  Search,
  Library,
  Heart,
  Clock,
  Radio,
  Sparkles,
  ListMusic,
  Plus,
  Settings,
  LogOut,
  Headphones,
} from "lucide-react";

interface Playlist {
  id: string;
  name: string;
}

interface AppSidebarProps {
  playlists?: Playlist[];
  userAvatar?: string;
  userName?: string;
  isAuthenticated?: boolean;
  onLogin?: () => void;
  onLogout?: () => void;
}

const mainNavItems = [
  { icon: Home, label: "Home", path: "/" },
  { icon: Search, label: "Search", path: "/search" },
  { icon: Library, label: "Your Library", path: "/library" },
];

const libraryItems = [
  { icon: Heart, label: "Liked Songs", path: "/liked" },
  { icon: Clock, label: "Recently Played", path: "/recent" },
  { icon: Radio, label: "Made For You", path: "/discover" },
];

const intelligenceItems = [
  { icon: Sparkles, label: "AI Recommendations", path: "/recommend" },
  { icon: ListMusic, label: "Smart Curator", path: "/curator" },
];

export default function AppSidebar({
  playlists = [],
  userAvatar,
  userName = "Guest",
  isAuthenticated = false,
  onLogin,
  onLogout,
}: AppSidebarProps) {
  const [location] = useLocation();

  return (
    <Sidebar data-testid="component-sidebar">
      <SidebarHeader className="p-4">
        <Link href="/" className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-md bg-primary flex items-center justify-center">
            <Headphones className="w-5 h-5 text-primary-foreground" />
          </div>
          <span className="text-lg font-bold">Sonar</span>
        </Link>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupContent>
            <SidebarMenu>
              {mainNavItems.map((item) => (
                <SidebarMenuItem key={item.path}>
                  <SidebarMenuButton
                    asChild
                    isActive={location === item.path}
                    data-testid={`nav-${item.label.toLowerCase().replace(" ", "-")}`}
                  >
                    <Link href={item.path}>
                      <item.icon className="w-5 h-5" />
                      <span>{item.label}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarSeparator />

        <SidebarGroup>
          <SidebarGroupLabel>Library</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {libraryItems.map((item) => (
                <SidebarMenuItem key={item.path}>
                  <SidebarMenuButton
                    asChild
                    isActive={location === item.path}
                    data-testid={`nav-${item.label.toLowerCase().replace(" ", "-")}`}
                  >
                    <Link href={item.path}>
                      <item.icon className="w-5 h-5" />
                      <span>{item.label}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarSeparator />

        <SidebarGroup>
          <SidebarGroupLabel className="flex items-center justify-between gap-2">
            <span>Intelligence</span>
            <Sparkles className="w-3 h-3 text-primary" />
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {intelligenceItems.map((item) => (
                <SidebarMenuItem key={item.path}>
                  <SidebarMenuButton
                    asChild
                    isActive={location === item.path}
                    data-testid={`nav-${item.label.toLowerCase().replace(" ", "-")}`}
                  >
                    <Link href={item.path}>
                      <item.icon className="w-5 h-5" />
                      <span>{item.label}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {playlists.length > 0 && (
          <>
            <SidebarSeparator />
            <SidebarGroup>
              <SidebarGroupLabel className="flex items-center justify-between gap-2">
                <span>Playlists</span>
                <Button
                  size="icon"
                  variant="ghost"
                  className="w-5 h-5"
                  data-testid="button-create-playlist"
                >
                  <Plus className="w-4 h-4" />
                </Button>
              </SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  {playlists.map((playlist) => (
                    <SidebarMenuItem key={playlist.id}>
                      <SidebarMenuButton
                        asChild
                        isActive={location === `/playlist/${playlist.id}`}
                        data-testid={`nav-playlist-${playlist.id}`}
                      >
                        <Link href={`/playlist/${playlist.id}`}>
                          <ListMusic className="w-4 h-4" />
                          <span className="truncate">{playlist.name}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
          </>
        )}
      </SidebarContent>

      <SidebarFooter className="p-4">
        {isAuthenticated ? (
          <div className="flex items-center gap-3">
            <Avatar className="w-8 h-8">
              <AvatarImage src={userAvatar} alt={userName} />
              <AvatarFallback>{userName.charAt(0).toUpperCase()}</AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">{userName}</p>
            </div>
            <Button
              size="icon"
              variant="ghost"
              onClick={onLogout}
              data-testid="button-logout"
            >
              <LogOut className="w-4 h-4" />
            </Button>
          </div>
        ) : (
          <Button className="w-full" onClick={onLogin} data-testid="button-login">
            Connect Spotify
          </Button>
        )}
      </SidebarFooter>
    </Sidebar>
  );
}
