import { useMemo } from "react";

interface AudioFeatures {
  acousticness: number;
  danceability: number;
  energy: number;
  instrumentalness: number;
  liveness: number;
  speechiness: number;
  valence: number;
}

interface AudioAnalysisRadarProps {
  features: AudioFeatures;
  size?: number;
  showLabels?: boolean;
  className?: string;
}

const FEATURE_LABELS: Record<keyof AudioFeatures, string> = {
  acousticness: "Acoustic",
  danceability: "Dance",
  energy: "Energy",
  instrumentalness: "Instrumental",
  liveness: "Live",
  speechiness: "Speech",
  valence: "Mood",
};

export default function AudioAnalysisRadar({
  features,
  size = 200,
  showLabels = true,
  className = "",
}: AudioAnalysisRadarProps) {
  const featureKeys = Object.keys(FEATURE_LABELS) as (keyof AudioFeatures)[];
  const numFeatures = featureKeys.length;
  const centerX = size / 2;
  const centerY = size / 2;
  const maxRadius = (size / 2) * 0.75;

  const points = useMemo(() => {
    return featureKeys.map((key, i) => {
      const angle = (Math.PI * 2 * i) / numFeatures - Math.PI / 2;
      const value = features[key];
      const radius = value * maxRadius;
      return {
        x: centerX + Math.cos(angle) * radius,
        y: centerY + Math.sin(angle) * radius,
        labelX: centerX + Math.cos(angle) * (maxRadius + 20),
        labelY: centerY + Math.sin(angle) * (maxRadius + 20),
        key,
        value,
        angle,
      };
    });
  }, [features, centerX, centerY, maxRadius, numFeatures]);

  const pathData = points
    .map((p, i) => `${i === 0 ? "M" : "L"} ${p.x} ${p.y}`)
    .join(" ") + " Z";

  const gridLines = [0.25, 0.5, 0.75, 1].map((scale) => {
    const gridPoints = featureKeys.map((_, i) => {
      const angle = (Math.PI * 2 * i) / numFeatures - Math.PI / 2;
      return {
        x: centerX + Math.cos(angle) * maxRadius * scale,
        y: centerY + Math.sin(angle) * maxRadius * scale,
      };
    });
    return gridPoints.map((p, i) => `${i === 0 ? "M" : "L"} ${p.x} ${p.y}`).join(" ") + " Z";
  });

  return (
    <div className={`relative ${className}`} data-testid="chart-audio-radar">
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        <defs>
          <linearGradient id="radarGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="hsl(var(--primary))" stopOpacity="0.8" />
            <stop offset="100%" stopColor="hsl(var(--chart-2))" stopOpacity="0.6" />
          </linearGradient>
        </defs>

        {gridLines.map((d, i) => (
          <path
            key={i}
            d={d}
            fill="none"
            stroke="hsl(var(--border))"
            strokeWidth="1"
            opacity={0.3 + i * 0.1}
          />
        ))}

        {featureKeys.map((_, i) => {
          const angle = (Math.PI * 2 * i) / numFeatures - Math.PI / 2;
          return (
            <line
              key={i}
              x1={centerX}
              y1={centerY}
              x2={centerX + Math.cos(angle) * maxRadius}
              y2={centerY + Math.sin(angle) * maxRadius}
              stroke="hsl(var(--border))"
              strokeWidth="1"
              opacity="0.3"
            />
          );
        })}

        <path
          d={pathData}
          fill="url(#radarGradient)"
          fillOpacity="0.3"
          stroke="hsl(var(--primary))"
          strokeWidth="2"
        />

        {points.map((p) => (
          <circle
            key={p.key}
            cx={p.x}
            cy={p.y}
            r="4"
            fill="hsl(var(--primary))"
            stroke="hsl(var(--background))"
            strokeWidth="2"
          />
        ))}

        {showLabels &&
          points.map((p) => (
            <text
              key={p.key}
              x={p.labelX}
              y={p.labelY}
              textAnchor="middle"
              dominantBaseline="middle"
              className="text-[10px] fill-muted-foreground"
            >
              {FEATURE_LABELS[p.key]}
            </text>
          ))}
      </svg>
    </div>
  );
}
