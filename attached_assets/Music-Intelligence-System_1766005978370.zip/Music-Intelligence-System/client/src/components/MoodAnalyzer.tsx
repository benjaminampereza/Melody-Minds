import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Smile,
  Frown,
  Meh,
  Zap,
  Music2,
  Heart,
  Cloud,
  Sun,
  Moon,
} from "lucide-react";

interface MoodProfile {
  valence: number;
  energy: number;
  danceability: number;
  acousticness: number;
}

interface MoodAnalyzerProps {
  trackTitle?: string;
  artistName?: string;
  mood: MoodProfile;
  className?: string;
}

const getMoodIcon = (valence: number, energy: number) => {
  if (valence > 0.6 && energy > 0.6) return { icon: Sun, label: "Euphoric", color: "text-yellow-500" };
  if (valence > 0.6 && energy <= 0.6) return { icon: Smile, label: "Content", color: "text-green-500" };
  if (valence > 0.4 && energy > 0.6) return { icon: Zap, label: "Energetic", color: "text-orange-500" };
  if (valence > 0.4) return { icon: Meh, label: "Neutral", color: "text-blue-400" };
  if (energy > 0.6) return { icon: Cloud, label: "Tense", color: "text-purple-500" };
  if (valence <= 0.3) return { icon: Moon, label: "Melancholic", color: "text-indigo-400" };
  return { icon: Frown, label: "Sad", color: "text-gray-500" };
};

const getMoodDescription = (mood: MoodProfile): string => {
  const { valence, energy, acousticness, danceability } = mood;
  
  let description = "";
  
  if (valence > 0.7) description += "Uplifting and positive. ";
  else if (valence < 0.3) description += "Deep and introspective. ";
  
  if (energy > 0.7) description += "High-intensity vibes. ";
  else if (energy < 0.3) description += "Calm and relaxing. ";
  
  if (danceability > 0.7) description += "Great for dancing. ";
  if (acousticness > 0.7) description += "Organic acoustic sound. ";
  
  return description.trim() || "Balanced and versatile.";
};

export default function MoodAnalyzer({
  trackTitle,
  artistName,
  mood,
  className = "",
}: MoodAnalyzerProps) {
  const moodInfo = getMoodIcon(mood.valence, mood.energy);
  const MoodIcon = moodInfo.icon;

  const metrics = [
    { label: "Happiness", value: mood.valence, icon: Heart, color: "bg-pink-500" },
    { label: "Energy", value: mood.energy, icon: Zap, color: "bg-orange-500" },
    { label: "Danceability", value: mood.danceability, icon: Music2, color: "bg-purple-500" },
    { label: "Acousticness", value: mood.acousticness, icon: Cloud, color: "bg-blue-500" },
  ];

  return (
    <Card className={`bg-card ${className}`} data-testid="card-mood-analyzer">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center justify-between gap-2 text-lg">
          <span className="flex items-center gap-2">
            <Heart className="w-5 h-5 text-primary" />
            Mood Analysis
          </span>
          <Badge variant="secondary" className={`${moodInfo.color} bg-transparent`}>
            <MoodIcon className="w-4 h-4 mr-1" />
            {moodInfo.label}
          </Badge>
        </CardTitle>
      </CardHeader>

      <CardContent className="space-y-4">
        {trackTitle && (
          <div className="text-center py-2">
            <p className="font-medium">{trackTitle}</p>
            {artistName && (
              <p className="text-sm text-muted-foreground">{artistName}</p>
            )}
          </div>
        )}

        <div className="flex justify-center">
          <div
            className={`w-24 h-24 rounded-full flex items-center justify-center ${moodInfo.color}`}
            style={{
              background: `conic-gradient(hsl(var(--primary)) ${mood.valence * 100}%, hsl(var(--muted)) 0)`,
            }}
          >
            <div className="w-20 h-20 rounded-full bg-card flex items-center justify-center">
              <MoodIcon className="w-10 h-10" />
            </div>
          </div>
        </div>

        <p
          className="text-sm text-center text-muted-foreground"
          data-testid="text-mood-description"
        >
          {getMoodDescription(mood)}
        </p>

        <div className="space-y-3">
          {metrics.map(({ label, value, icon: Icon, color }) => (
            <div key={label} className="space-y-1">
              <div className="flex items-center justify-between gap-2 text-sm">
                <span className="flex items-center gap-2">
                  <Icon className="w-4 h-4 text-muted-foreground" />
                  {label}
                </span>
                <span className="text-muted-foreground">
                  {Math.round(value * 100)}%
                </span>
              </div>
              <Progress value={value * 100} className="h-2" />
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
