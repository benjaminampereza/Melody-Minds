import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Play, Pause } from "lucide-react";

interface PlaylistCardProps {
  id: string;
  name: string;
  description?: string;
  coverImage: string;
  trackCount: number;
  isPlaying?: boolean;
  onPlay?: () => void;
  onPause?: () => void;
  onClick?: () => void;
}

export default function PlaylistCard({
  id,
  name,
  description,
  coverImage,
  trackCount,
  isPlaying = false,
  onPlay,
  onPause,
  onClick,
}: PlaylistCardProps) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div
      className="group p-4 rounded-md bg-card hover-elevate active-elevate-2 cursor-pointer transition-all duration-200"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={onClick}
      data-testid={`card-playlist-${id}`}
    >
      <div className="relative aspect-square rounded-md overflow-hidden mb-4 shadow-lg">
        <img
          src={coverImage}
          alt={name}
          className="w-full h-full object-cover"
          data-testid={`img-playlist-cover-${id}`}
        />
        <div
          className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"
          style={{ opacity: isHovered ? 1 : 0, transition: "opacity 200ms" }}
        />
        <Button
          size="icon"
          variant="default"
          className={`absolute bottom-2 right-2 w-12 h-12 rounded-full shadow-xl transition-all duration-200 ${
            isHovered || isPlaying
              ? "opacity-100 translate-y-0"
              : "opacity-0 translate-y-2"
          }`}
          style={{ visibility: isHovered || isPlaying ? "visible" : "hidden" }}
          onClick={(e) => {
            e.stopPropagation();
            isPlaying ? onPause?.() : onPlay?.();
          }}
          data-testid={`button-play-playlist-${id}`}
        >
          {isPlaying ? (
            <Pause className="w-6 h-6" />
          ) : (
            <Play className="w-6 h-6 ml-1" />
          )}
        </Button>
      </div>

      <div className="space-y-1">
        <h3
          className="font-semibold text-sm truncate"
          data-testid={`text-playlist-name-${id}`}
        >
          {name}
        </h3>
        {description && (
          <p
            className="text-xs text-muted-foreground line-clamp-2"
            data-testid={`text-playlist-desc-${id}`}
          >
            {description}
          </p>
        )}
        <p className="text-xs text-muted-foreground">
          {trackCount} {trackCount === 1 ? "track" : "tracks"}
        </p>
      </div>
    </div>
  );
}
