import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import {
  Wand2,
  Plus,
  Trash2,
  GripVertical,
  Play,
  ArrowUpDown,
  Sparkles,
  Music,
  Save,
} from "lucide-react";

interface CuratorTrack {
  id: string;
  title: string;
  artist: string;
  albumArt: string;
  tempo: number;
  energy: number;
  key: string;
}

interface PlaylistCuratorProps {
  tracks?: CuratorTrack[];
  isGenerating?: boolean;
  flowScore?: number;
  onGenerateFromPrompt?: (prompt: string) => void;
  onOptimizeOrder?: () => void;
  onRemoveTrack?: (id: string) => void;
  onSavePlaylist?: () => void;
}

export default function PlaylistCurator({
  tracks = [],
  isGenerating = false,
  flowScore = 0,
  onGenerateFromPrompt,
  onOptimizeOrder,
  onRemoveTrack,
  onSavePlaylist,
}: PlaylistCuratorProps) {
  const [prompt, setPrompt] = useState("");
  const [showPrompt, setShowPrompt] = useState(tracks.length === 0);

  const handleGenerate = () => {
    if (prompt.trim()) {
      onGenerateFromPrompt?.(prompt);
      setShowPrompt(false);
    }
  };

  return (
    <Card className="bg-card" data-testid="card-playlist-curator">
      <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
        <CardTitle className="flex items-center gap-2 text-lg">
          <Wand2 className="w-5 h-5 text-primary" />
          Smart Curator
        </CardTitle>
        {tracks.length > 0 && (
          <div className="flex items-center gap-2">
            <Badge variant="secondary" className="text-xs">
              Flow: {Math.round(flowScore * 100)}%
            </Badge>
            <Button
              size="sm"
              variant="outline"
              onClick={onOptimizeOrder}
              data-testid="button-optimize"
            >
              <ArrowUpDown className="w-4 h-4 mr-1" />
              Optimize
            </Button>
            <Button
              size="sm"
              onClick={onSavePlaylist}
              data-testid="button-save-playlist"
            >
              <Save className="w-4 h-4 mr-1" />
              Save
            </Button>
          </div>
        )}
      </CardHeader>

      <CardContent className="space-y-4">
        {showPrompt && (
          <div className="space-y-3">
            <Textarea
              placeholder="Describe the playlist you want... (e.g., 'upbeat morning workout music with 80s vibes' or 'relaxing acoustic songs for a rainy day')"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              className="min-h-[80px]"
              data-testid="textarea-prompt"
            />
            <div className="flex items-center gap-2 flex-wrap">
              <Badge
                variant="outline"
                className="cursor-pointer"
                onClick={() => setPrompt("High energy workout mix")}
              >
                Workout
              </Badge>
              <Badge
                variant="outline"
                className="cursor-pointer"
                onClick={() => setPrompt("Relaxing evening vibes")}
              >
                Chill
              </Badge>
              <Badge
                variant="outline"
                className="cursor-pointer"
                onClick={() => setPrompt("Focus and concentration music")}
              >
                Focus
              </Badge>
              <Badge
                variant="outline"
                className="cursor-pointer"
                onClick={() => setPrompt("Party anthems for dancing")}
              >
                Party
              </Badge>
            </div>
            <Button
              className="w-full"
              onClick={handleGenerate}
              disabled={!prompt.trim() || isGenerating}
              data-testid="button-generate-playlist"
            >
              {isGenerating ? (
                <>
                  <Sparkles className="w-4 h-4 mr-2 animate-pulse" />
                  Curating...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 mr-2" />
                  Generate Playlist
                </>
              )}
            </Button>
          </div>
        )}

        {!showPrompt && tracks.length === 0 && isGenerating && (
          <div className="py-8 text-center">
            <Sparkles className="w-12 h-12 mx-auto text-primary animate-pulse mb-3" />
            <p className="text-sm text-muted-foreground">
              AI is curating your perfect playlist...
            </p>
            <Progress value={45} className="mt-4 max-w-xs mx-auto" />
          </div>
        )}

        {tracks.length > 0 && (
          <div className="space-y-2">
            {tracks.map((track, index) => (
              <div
                key={track.id}
                className="flex items-center gap-3 p-2 rounded-md bg-background group hover-elevate"
                data-testid={`curator-track-${track.id}`}
              >
                <GripVertical className="w-4 h-4 text-muted-foreground opacity-0 group-hover:opacity-100 cursor-grab" />
                <span className="w-6 text-sm text-muted-foreground text-center">
                  {index + 1}
                </span>
                <img
                  src={track.albumArt}
                  alt={track.title}
                  className="w-10 h-10 rounded object-cover"
                />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{track.title}</p>
                  <p className="text-xs text-muted-foreground truncate">
                    {track.artist}
                  </p>
                </div>
                <div className="hidden md:flex items-center gap-2 text-xs text-muted-foreground">
                  <span>{track.tempo} BPM</span>
                  <span className="text-muted-foreground/50">|</span>
                  <span>{track.key}</span>
                </div>
                <Button
                  size="icon"
                  variant="ghost"
                  className="opacity-0 group-hover:opacity-100"
                  onClick={() => onRemoveTrack?.(track.id)}
                  data-testid={`button-remove-${track.id}`}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            ))}
            
            <Button
              variant="outline"
              className="w-full mt-4"
              onClick={() => setShowPrompt(true)}
              data-testid="button-add-more"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add More Tracks
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
