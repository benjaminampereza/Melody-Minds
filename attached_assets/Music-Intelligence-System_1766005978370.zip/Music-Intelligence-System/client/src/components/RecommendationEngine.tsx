import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { Sparkles, RefreshCw, Plus, Zap, Music, Smile, Mic2 } from "lucide-react";

interface RecommendationParams {
  energy: number;
  danceability: number;
  valence: number;
  tempo: number;
  acousticness: number;
}

interface RecommendedTrack {
  id: string;
  title: string;
  artist: string;
  albumArt: string;
  matchScore: number;
  reason: string;
}

interface RecommendationEngineProps {
  initialParams?: RecommendationParams;
  recommendations?: RecommendedTrack[];
  isLoading?: boolean;
  onGenerateRecommendations?: (params: RecommendationParams) => void;
  onAddToPlaylist?: (trackId: string) => void;
}

const PARAM_CONFIG = [
  { key: "energy", label: "Energy", icon: Zap, min: 0, max: 100 },
  { key: "danceability", label: "Danceability", icon: Music, min: 0, max: 100 },
  { key: "valence", label: "Mood (Sad-Happy)", icon: Smile, min: 0, max: 100 },
  { key: "tempo", label: "Tempo (BPM)", icon: RefreshCw, min: 60, max: 200 },
  { key: "acousticness", label: "Acousticness", icon: Mic2, min: 0, max: 100 },
] as const;

export default function RecommendationEngine({
  initialParams = { energy: 70, danceability: 60, valence: 50, tempo: 120, acousticness: 20 },
  recommendations = [],
  isLoading = false,
  onGenerateRecommendations,
  onAddToPlaylist,
}: RecommendationEngineProps) {
  const [params, setParams] = useState<RecommendationParams>(initialParams);

  const updateParam = (key: keyof RecommendationParams, value: number) => {
    setParams((prev) => ({ ...prev, [key]: value }));
  };

  return (
    <Card className="bg-card" data-testid="card-recommendation-engine">
      <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
        <CardTitle className="flex items-center gap-2 text-lg">
          <Sparkles className="w-5 h-5 text-primary" />
          AI Recommendations
        </CardTitle>
        <Button
          size="sm"
          onClick={() => onGenerateRecommendations?.(params)}
          disabled={isLoading}
          data-testid="button-generate-recommendations"
        >
          {isLoading ? (
            <RefreshCw className="w-4 h-4 animate-spin mr-2" />
          ) : (
            <Sparkles className="w-4 h-4 mr-2" />
          )}
          Generate
        </Button>
      </CardHeader>

      <CardContent className="space-y-6">
        <div className="space-y-4">
          {PARAM_CONFIG.map(({ key, label, icon: Icon, min, max }) => (
            <div key={key} className="space-y-2">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <Icon className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm font-medium">{label}</span>
                </div>
                <span className="text-sm text-muted-foreground">
                  {params[key as keyof RecommendationParams]}
                  {key === "tempo" ? " BPM" : "%"}
                </span>
              </div>
              <Slider
                value={[params[key as keyof RecommendationParams]]}
                min={min}
                max={max}
                step={1}
                onValueChange={(v) => updateParam(key as keyof RecommendationParams, v[0])}
                data-testid={`slider-${key}`}
              />
            </div>
          ))}
        </div>

        {recommendations.length > 0 && (
          <div className="space-y-2">
            <h4 className="text-sm font-medium text-muted-foreground">
              Recommended for you
            </h4>
            <div className="space-y-2">
              {recommendations.map((track) => (
                <div
                  key={track.id}
                  className="flex items-center gap-3 p-2 rounded-md bg-background hover-elevate"
                  data-testid={`card-recommendation-${track.id}`}
                >
                  <img
                    src={track.albumArt}
                    alt={track.title}
                    className="w-10 h-10 rounded object-cover"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{track.title}</p>
                    <p className="text-xs text-muted-foreground truncate">
                      {track.artist}
                    </p>
                  </div>
                  <Badge variant="secondary" className="text-xs">
                    {Math.round(track.matchScore * 100)}% match
                  </Badge>
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={() => onAddToPlaylist?.(track.id)}
                    data-testid={`button-add-recommendation-${track.id}`}
                  >
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
