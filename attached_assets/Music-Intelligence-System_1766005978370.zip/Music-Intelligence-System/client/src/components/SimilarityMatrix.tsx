import { useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { GitCompare } from "lucide-react";

interface TrackSimilarity {
  id: string;
  title: string;
  artist: string;
  similarity: number[][];
}

interface SimilarityMatrixProps {
  tracks: { id: string; title: string; artist: string }[];
  matrix: number[][];
  className?: string;
}

const getColorForSimilarity = (value: number): string => {
  if (value >= 0.9) return "bg-primary";
  if (value >= 0.7) return "bg-primary/80";
  if (value >= 0.5) return "bg-primary/60";
  if (value >= 0.3) return "bg-primary/40";
  return "bg-muted";
};

export default function SimilarityMatrix({
  tracks,
  matrix,
  className = "",
}: SimilarityMatrixProps) {
  const maxSize = 8;
  const displayTracks = tracks.slice(0, maxSize);
  const displayMatrix = matrix.slice(0, maxSize).map((row) => row.slice(0, maxSize));

  return (
    <Card className={`bg-card ${className}`} data-testid="card-similarity-matrix">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2 text-lg">
          <GitCompare className="w-5 h-5 text-primary" />
          Track Similarity
        </CardTitle>
      </CardHeader>

      <CardContent>
        <div className="overflow-x-auto">
          <div className="min-w-fit">
            <div className="flex">
              <div className="w-24 flex-shrink-0" />
              {displayTracks.map((track, i) => (
                <div
                  key={track.id}
                  className="w-10 h-20 flex items-end justify-center pb-1"
                  title={`${track.title} - ${track.artist}`}
                >
                  <span
                    className="text-[10px] text-muted-foreground transform -rotate-45 origin-bottom-left whitespace-nowrap truncate max-w-[60px]"
                  >
                    {track.title.slice(0, 10)}
                  </span>
                </div>
              ))}
            </div>

            {displayMatrix.map((row, i) => (
              <div key={displayTracks[i]?.id || i} className="flex items-center">
                <div
                  className="w-24 flex-shrink-0 text-xs text-muted-foreground truncate pr-2"
                  title={`${displayTracks[i]?.title} - ${displayTracks[i]?.artist}`}
                >
                  {displayTracks[i]?.title.slice(0, 12)}
                </div>
                {row.map((value, j) => (
                  <div
                    key={j}
                    className={`w-10 h-10 flex items-center justify-center rounded-sm m-0.5 ${getColorForSimilarity(value)} transition-colors`}
                    title={`${displayTracks[i]?.title} vs ${displayTracks[j]?.title}: ${Math.round(value * 100)}%`}
                    data-testid={`cell-${i}-${j}`}
                  >
                    {i === j ? (
                      <span className="text-[10px] font-bold text-primary-foreground">
                        1.0
                      </span>
                    ) : (
                      <span className="text-[10px] text-primary-foreground">
                        {value.toFixed(1)}
                      </span>
                    )}
                  </div>
                ))}
              </div>
            ))}
          </div>
        </div>

        <div className="flex items-center justify-center gap-4 mt-4 text-xs text-muted-foreground">
          <div className="flex items-center gap-1">
            <div className="w-3 h-3 rounded-sm bg-muted" />
            <span>Low</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="w-3 h-3 rounded-sm bg-primary/60" />
            <span>Medium</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="w-3 h-3 rounded-sm bg-primary" />
            <span>High</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
