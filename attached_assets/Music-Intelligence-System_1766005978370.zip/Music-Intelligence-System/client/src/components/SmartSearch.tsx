import { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Search,
  Mic,
  X,
  Clock,
  TrendingUp,
  Sparkles,
  Music,
  User,
  Disc,
} from "lucide-react";

interface SearchResult {
  id: string;
  type: "track" | "artist" | "album" | "playlist";
  title: string;
  subtitle?: string;
  image?: string;
}

interface SmartSearchProps {
  placeholder?: string;
  suggestions?: string[];
  recentSearches?: string[];
  results?: SearchResult[];
  isLoading?: boolean;
  onSearch?: (query: string) => void;
  onResultClick?: (result: SearchResult) => void;
  onClearRecent?: () => void;
}

const TYPE_ICONS = {
  track: Music,
  artist: User,
  album: Disc,
  playlist: Music,
};

export default function SmartSearch({
  placeholder = "Search for songs, artists, or describe a mood...",
  suggestions = [],
  recentSearches = [],
  results = [],
  isLoading = false,
  onSearch,
  onResultClick,
  onClearRecent,
}: SmartSearchProps) {
  const [query, setQuery] = useState("");
  const [isFocused, setIsFocused] = useState(false);

  const showDropdown = isFocused && (query.length > 0 || recentSearches.length > 0 || suggestions.length > 0);

  useEffect(() => {
    const timeoutId = setTimeout(() => {
      if (query.length >= 2) {
        onSearch?.(query);
      }
    }, 300);
    return () => clearTimeout(timeoutId);
  }, [query, onSearch]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      onSearch?.(query);
    }
  };

  return (
    <div className="relative w-full max-w-xl" data-testid="component-smart-search">
      <form onSubmit={handleSubmit}>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <Input
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onFocus={() => setIsFocused(true)}
            onBlur={() => setTimeout(() => setIsFocused(false), 200)}
            placeholder={placeholder}
            className="pl-10 pr-20 h-12 text-base rounded-full bg-card"
            data-testid="input-search"
          />
          <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
            {query && (
              <Button
                type="button"
                size="icon"
                variant="ghost"
                className="w-8 h-8"
                onClick={() => setQuery("")}
                data-testid="button-clear-search"
              >
                <X className="w-4 h-4" />
              </Button>
            )}
            <Button
              type="button"
              size="icon"
              variant="ghost"
              className="w-8 h-8"
              data-testid="button-voice-search"
            >
              <Mic className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </form>

      {showDropdown && (
        <div className="absolute top-full left-0 right-0 mt-2 py-2 bg-card rounded-lg border border-border shadow-xl z-50">
          {query.length > 0 && suggestions.length > 0 && (
            <div className="px-3 py-2">
              <div className="flex items-center gap-2 text-xs text-muted-foreground mb-2">
                <Sparkles className="w-3 h-3" />
                AI Suggestions
              </div>
              <div className="flex flex-wrap gap-2">
                {suggestions.map((suggestion, i) => (
                  <Badge
                    key={i}
                    variant="secondary"
                    className="cursor-pointer"
                    onClick={() => {
                      setQuery(suggestion);
                      onSearch?.(suggestion);
                    }}
                    data-testid={`badge-suggestion-${i}`}
                  >
                    {suggestion}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {results.length > 0 && (
            <div className="px-1">
              {results.map((result) => {
                const Icon = TYPE_ICONS[result.type];
                return (
                  <div
                    key={result.id}
                    className="flex items-center gap-3 px-3 py-2 rounded-md hover-elevate cursor-pointer"
                    onClick={() => onResultClick?.(result)}
                    data-testid={`result-${result.id}`}
                  >
                    {result.image ? (
                      <img
                        src={result.image}
                        alt={result.title}
                        className="w-10 h-10 rounded object-cover"
                      />
                    ) : (
                      <div className="w-10 h-10 rounded bg-muted flex items-center justify-center">
                        <Icon className="w-5 h-5 text-muted-foreground" />
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{result.title}</p>
                      <p className="text-xs text-muted-foreground truncate">
                        {result.subtitle}
                      </p>
                    </div>
                    <Badge variant="outline" className="text-xs capitalize">
                      {result.type}
                    </Badge>
                  </div>
                );
              })}
            </div>
          )}

          {query.length === 0 && recentSearches.length > 0 && (
            <div className="px-1">
              <div className="flex items-center justify-between gap-2 px-3 py-2">
                <span className="text-xs text-muted-foreground flex items-center gap-2">
                  <Clock className="w-3 h-3" />
                  Recent Searches
                </span>
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-xs h-6"
                  onClick={onClearRecent}
                  data-testid="button-clear-recent"
                >
                  Clear
                </Button>
              </div>
              {recentSearches.map((search, i) => (
                <div
                  key={i}
                  className="flex items-center gap-3 px-3 py-2 rounded-md hover-elevate cursor-pointer"
                  onClick={() => {
                    setQuery(search);
                    onSearch?.(search);
                  }}
                  data-testid={`recent-search-${i}`}
                >
                  <Clock className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm">{search}</span>
                </div>
              ))}
            </div>
          )}

          {isLoading && (
            <div className="px-3 py-4 text-center text-sm text-muted-foreground">
              Searching...
            </div>
          )}
        </div>
      )}
    </div>
  );
}
