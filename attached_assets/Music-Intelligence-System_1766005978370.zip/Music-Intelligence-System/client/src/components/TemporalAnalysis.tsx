import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Clock, Sun, Moon, Coffee, Sunset } from "lucide-react";

interface TimeSlot {
  label: string;
  icon: typeof Sun;
  start: number;
  end: number;
  tracks: number;
  topGenre: string;
  avgEnergy: number;
}

interface TemporalAnalysisProps {
  data: {
    morning: { tracks: number; topGenre: string; avgEnergy: number };
    afternoon: { tracks: number; topGenre: string; avgEnergy: number };
    evening: { tracks: number; topGenre: string; avgEnergy: number };
    night: { tracks: number; topGenre: string; avgEnergy: number };
  };
  className?: string;
}

const TIME_SLOTS: Omit<TimeSlot, "tracks" | "topGenre" | "avgEnergy">[] = [
  { label: "Morning", icon: Coffee, start: 6, end: 12 },
  { label: "Afternoon", icon: Sun, start: 12, end: 17 },
  { label: "Evening", icon: Sunset, start: 17, end: 21 },
  { label: "Night", icon: Moon, start: 21, end: 6 },
];

export default function TemporalAnalysis({
  data,
  className = "",
}: TemporalAnalysisProps) {
  const slots: TimeSlot[] = TIME_SLOTS.map((slot) => ({
    ...slot,
    ...(data[slot.label.toLowerCase() as keyof typeof data] || {
      tracks: 0,
      topGenre: "N/A",
      avgEnergy: 0,
    }),
  }));

  const totalTracks = slots.reduce((sum, s) => sum + s.tracks, 0);

  return (
    <Card className={`bg-card ${className}`} data-testid="card-temporal-analysis">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2 text-lg">
          <Clock className="w-5 h-5 text-primary" />
          Listening Patterns
        </CardTitle>
      </CardHeader>

      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-3">
          {slots.map((slot) => {
            const Icon = slot.icon;
            const percentage = totalTracks > 0 ? (slot.tracks / totalTracks) * 100 : 0;

            return (
              <div
                key={slot.label}
                className="p-3 rounded-md bg-background space-y-2"
                data-testid={`slot-${slot.label.toLowerCase()}`}
              >
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <Icon className="w-4 h-4 text-primary" />
                    <span className="text-sm font-medium">{slot.label}</span>
                  </div>
                  <span className="text-xs text-muted-foreground">
                    {slot.start}:00 - {slot.end === 6 ? "6:00" : `${slot.end}:00`}
                  </span>
                </div>

                <div className="h-2 rounded-full bg-muted overflow-hidden">
                  <div
                    className="h-full bg-primary transition-all"
                    style={{ width: `${percentage}%` }}
                  />
                </div>

                <div className="flex items-center justify-between gap-2 text-xs">
                  <span className="text-muted-foreground">
                    {slot.tracks} tracks ({Math.round(percentage)}%)
                  </span>
                  <Badge variant="secondary" className="text-xs">
                    {slot.topGenre}
                  </Badge>
                </div>

                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <span>Avg Energy:</span>
                  <div className="flex-1 h-1.5 rounded-full bg-muted overflow-hidden">
                    <div
                      className="h-full bg-chart-2"
                      style={{ width: `${slot.avgEnergy * 100}%` }}
                    />
                  </div>
                  <span>{Math.round(slot.avgEnergy * 100)}%</span>
                </div>
              </div>
            );
          })}
        </div>

        <div className="text-center text-xs text-muted-foreground">
          Based on your last 30 days of listening history
        </div>
      </CardContent>
    </Card>
  );
}
