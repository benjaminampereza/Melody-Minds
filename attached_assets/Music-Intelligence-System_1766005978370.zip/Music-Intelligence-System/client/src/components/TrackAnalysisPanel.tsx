import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import AudioAnalysisRadar from "./AudioAnalysisRadar";
import {
  Music2,
  Activity,
  Gauge,
  Key,
  Timer,
  Volume2,
  Mic2,
  Radio,
} from "lucide-react";

interface AudioFeatures {
  acousticness: number;
  danceability: number;
  energy: number;
  instrumentalness: number;
  liveness: number;
  speechiness: number;
  valence: number;
  tempo: number;
  key: string;
  mode: string;
  timeSignature: string;
  loudness: number;
  duration: number;
}

interface TrackAnalysisPanelProps {
  trackTitle: string;
  artistName: string;
  albumArt: string;
  features: AudioFeatures;
  className?: string;
}

const KEY_NAMES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"];

export default function TrackAnalysisPanel({
  trackTitle,
  artistName,
  albumArt,
  features,
  className = "",
}: TrackAnalysisPanelProps) {
  const radarFeatures = {
    acousticness: features.acousticness,
    danceability: features.danceability,
    energy: features.energy,
    instrumentalness: features.instrumentalness,
    liveness: features.liveness,
    speechiness: features.speechiness,
    valence: features.valence,
  };

  const technicalMetrics = [
    { icon: Gauge, label: "Tempo", value: `${Math.round(features.tempo)} BPM` },
    { icon: Key, label: "Key", value: `${features.key} ${features.mode}` },
    { icon: Timer, label: "Time Sig", value: features.timeSignature },
    { icon: Volume2, label: "Loudness", value: `${features.loudness.toFixed(1)} dB` },
  ];

  const featuresList = [
    { label: "Energy", value: features.energy, color: "bg-orange-500" },
    { label: "Danceability", value: features.danceability, color: "bg-purple-500" },
    { label: "Valence", value: features.valence, color: "bg-yellow-500" },
    { label: "Acousticness", value: features.acousticness, color: "bg-blue-500" },
    { label: "Instrumentalness", value: features.instrumentalness, color: "bg-teal-500" },
    { label: "Liveness", value: features.liveness, color: "bg-pink-500" },
    { label: "Speechiness", value: features.speechiness, color: "bg-indigo-500" },
  ];

  return (
    <Card className={`bg-card ${className}`} data-testid="card-track-analysis">
      <CardHeader className="pb-2">
        <div className="flex items-center gap-4">
          <img
            src={albumArt}
            alt={trackTitle}
            className="w-16 h-16 rounded-md object-cover"
            data-testid="img-analysis-album"
          />
          <div className="flex-1 min-w-0">
            <CardTitle className="text-lg truncate" data-testid="text-analysis-title">
              {trackTitle}
            </CardTitle>
            <p className="text-sm text-muted-foreground truncate">{artistName}</p>
          </div>
        </div>
      </CardHeader>

      <CardContent>
        <Tabs defaultValue="radar" className="w-full">
          <TabsList className="w-full grid grid-cols-3 mb-4">
            <TabsTrigger value="radar" data-testid="tab-radar">
              <Radio className="w-4 h-4 mr-1" />
              Radar
            </TabsTrigger>
            <TabsTrigger value="features" data-testid="tab-features">
              <Activity className="w-4 h-4 mr-1" />
              Features
            </TabsTrigger>
            <TabsTrigger value="technical" data-testid="tab-technical">
              <Music2 className="w-4 h-4 mr-1" />
              Technical
            </TabsTrigger>
          </TabsList>

          <TabsContent value="radar" className="flex justify-center">
            <AudioAnalysisRadar features={radarFeatures} size={220} />
          </TabsContent>

          <TabsContent value="features" className="space-y-3">
            {featuresList.map(({ label, value, color }) => (
              <div key={label} className="space-y-1">
                <div className="flex items-center justify-between gap-2 text-sm">
                  <span>{label}</span>
                  <span className="text-muted-foreground">
                    {Math.round(value * 100)}%
                  </span>
                </div>
                <div className="h-2 rounded-full bg-muted overflow-hidden">
                  <div
                    className={`h-full ${color} transition-all`}
                    style={{ width: `${value * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </TabsContent>

          <TabsContent value="technical">
            <div className="grid grid-cols-2 gap-3">
              {technicalMetrics.map(({ icon: Icon, label, value }) => (
                <div
                  key={label}
                  className="p-3 rounded-md bg-background text-center"
                >
                  <Icon className="w-5 h-5 mx-auto mb-1 text-primary" />
                  <p className="text-xs text-muted-foreground">{label}</p>
                  <p className="text-sm font-medium">{value}</p>
                </div>
              ))}
            </div>

            <div className="mt-4 p-3 rounded-md bg-background">
              <div className="flex items-center justify-between gap-2 text-sm">
                <span className="flex items-center gap-2">
                  <Timer className="w-4 h-4 text-muted-foreground" />
                  Duration
                </span>
                <span>
                  {Math.floor(features.duration / 60)}:
                  {String(Math.floor(features.duration % 60)).padStart(2, "0")}
                </span>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
