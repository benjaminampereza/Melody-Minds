import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Play, Pause, MoreHorizontal, Heart } from "lucide-react";

interface AudioFeatures {
  energy: number;
  danceability: number;
  valence: number;
  tempo: number;
}

interface TrackCardProps {
  id: string;
  title: string;
  artist: string;
  album: string;
  albumArt: string;
  duration: string;
  isPlaying?: boolean;
  showFeatures?: boolean;
  features?: AudioFeatures;
  onPlay?: () => void;
  onPause?: () => void;
}

export default function TrackCard({
  id,
  title,
  artist,
  album,
  albumArt,
  duration,
  isPlaying = false,
  showFeatures = false,
  features,
  onPlay,
  onPause,
}: TrackCardProps) {
  const [isHovered, setIsHovered] = useState(false);
  const [isLiked, setIsLiked] = useState(false);

  const getEnergyColor = (value: number) => {
    if (value >= 0.7) return "bg-primary";
    if (value >= 0.4) return "bg-chart-2";
    return "bg-chart-4";
  };

  return (
    <div
      className="group flex items-center gap-3 p-2 rounded-md hover-elevate active-elevate-2 cursor-pointer"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      data-testid={`card-track-${id}`}
    >
      <div className="relative w-12 h-12 rounded-md overflow-hidden flex-shrink-0 bg-muted">
        <img
          src={albumArt}
          alt={album}
          className="w-full h-full object-cover"
          data-testid={`img-track-art-${id}`}
        />
        <div
          className={`absolute inset-0 bg-black/60 flex items-center justify-center transition-opacity ${
            isHovered || isPlaying ? "opacity-100" : "opacity-0"
          }`}
        >
          <Button
            size="icon"
            variant="ghost"
            className="text-white"
            onClick={(e) => {
              e.stopPropagation();
              isPlaying ? onPause?.() : onPlay?.();
            }}
            data-testid={`button-play-track-${id}`}
          >
            {isPlaying ? (
              <Pause className="w-5 h-5" />
            ) : (
              <Play className="w-5 h-5 ml-0.5" />
            )}
          </Button>
        </div>
      </div>

      <div className="flex-1 min-w-0">
        <p
          className={`text-sm font-medium truncate ${isPlaying ? "text-primary" : ""}`}
          data-testid={`text-track-title-${id}`}
        >
          {title}
        </p>
        <p
          className="text-xs text-muted-foreground truncate"
          data-testid={`text-track-artist-${id}`}
        >
          {artist}
        </p>
      </div>

      {showFeatures && features && (
        <div className="hidden md:flex items-center gap-2">
          <Badge variant="secondary" className="text-xs">
            {Math.round(features.tempo)} BPM
          </Badge>
          <div className="flex items-center gap-1">
            <div
              className={`w-2 h-2 rounded-full ${getEnergyColor(features.energy)}`}
              title={`Energy: ${Math.round(features.energy * 100)}%`}
            />
            <span className="text-xs text-muted-foreground">
              {Math.round(features.energy * 100)}%
            </span>
          </div>
        </div>
      )}

      <Button
        size="icon"
        variant="ghost"
        className={`${isLiked ? "opacity-100" : "opacity-0 group-hover:opacity-100"} transition-opacity`}
        style={{ visibility: isLiked || isHovered ? "visible" : "hidden" }}
        onClick={(e) => {
          e.stopPropagation();
          setIsLiked(!isLiked);
        }}
        data-testid={`button-like-track-${id}`}
      >
        <Heart
          className={`w-4 h-4 ${isLiked ? "fill-primary text-primary" : ""}`}
        />
      </Button>

      <span className="text-xs text-muted-foreground w-10 text-right">
        {duration}
      </span>

      <Button
        size="icon"
        variant="ghost"
        className="opacity-0 group-hover:opacity-100 transition-opacity"
        style={{ visibility: isHovered ? "visible" : "hidden" }}
        data-testid={`button-more-track-${id}`}
      >
        <MoreHorizontal className="w-4 h-4" />
      </Button>
    </div>
  );
}
