import { SidebarProvider } from "@/components/ui/sidebar";
import AppSidebar from "../AppSidebar";

export default function AppSidebarExample() {
  // todo: remove mock functionality
  const mockPlaylists = [
    { id: "1", name: "Chill Vibes" },
    { id: "2", name: "Workout Mix" },
    { id: "3", name: "Focus Flow" },
  ];

  const style = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "3rem",
  };

  return (
    <SidebarProvider style={style as React.CSSProperties}>
      <div className="flex h-[500px] w-full bg-background rounded-lg overflow-hidden">
        <AppSidebar
          playlists={mockPlaylists}
          isAuthenticated={true}
          userName="John Doe"
          onLogin={() => console.log("Login clicked")}
          onLogout={() => console.log("Logout clicked")}
        />
        <div className="flex-1 p-6 flex items-center justify-center text-muted-foreground">
          Main Content Area
        </div>
      </div>
    </SidebarProvider>
  );
}
