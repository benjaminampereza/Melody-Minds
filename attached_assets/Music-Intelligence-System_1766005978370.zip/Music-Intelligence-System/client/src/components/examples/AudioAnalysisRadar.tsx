import AudioAnalysisRadar from "../AudioAnalysisRadar";

export default function AudioAnalysisRadarExample() {
  // todo: remove mock functionality
  const mockFeatures = {
    acousticness: 0.15,
    danceability: 0.68,
    energy: 0.82,
    instrumentalness: 0.02,
    liveness: 0.12,
    speechiness: 0.08,
    valence: 0.45,
  };

  return (
    <div className="flex items-center justify-center p-6 bg-background rounded-lg">
      <AudioAnalysisRadar features={mockFeatures} size={280} showLabels />
    </div>
  );
}
