import MoodAnalyzer from "../MoodAnalyzer";

export default function MoodAnalyzerExample() {
  // todo: remove mock functionality
  const mockMood = {
    valence: 0.75,
    energy: 0.82,
    danceability: 0.68,
    acousticness: 0.15,
  };

  return (
    <div className="max-w-sm p-4 bg-background rounded-lg">
      <MoodAnalyzer
        trackTitle="Blinding Lights"
        artistName="The Weeknd"
        mood={mockMood}
      />
    </div>
  );
}
