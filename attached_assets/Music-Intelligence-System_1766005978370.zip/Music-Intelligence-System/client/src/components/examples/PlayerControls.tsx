import { useState } from "react";
import PlayerControls from "../PlayerControls";

export default function PlayerControlsExample() {
  const [isPlaying, setIsPlaying] = useState(true);
  const [progress, setProgress] = useState(35);
  const [shuffle, setShuffle] = useState(false);
  const [repeat, setRepeat] = useState<"off" | "all" | "one">("off");

  // todo: remove mock functionality
  const mockTrack = {
    id: "1",
    title: "Blinding Lights",
    artist: "The Weeknd",
    album: "After Hours",
    albumArt: "https://i.scdn.co/image/ab67616d0000b2738863bc11d2aa12b54f5aeb36",
    duration: 200,
  };

  const handleRepeatToggle = () => {
    const states: ("off" | "all" | "one")[] = ["off", "all", "one"];
    const currentIndex = states.indexOf(repeat);
    setRepeat(states[(currentIndex + 1) % 3]);
  };

  return (
    <div className="h-24">
      <PlayerControls
        currentTrack={mockTrack}
        isPlaying={isPlaying}
        progress={progress}
        shuffle={shuffle}
        repeat={repeat}
        onPlayPause={() => setIsPlaying(!isPlaying)}
        onNext={() => console.log("Next track")}
        onPrevious={() => console.log("Previous track")}
        onSeek={setProgress}
        onShuffleToggle={() => setShuffle(!shuffle)}
        onRepeatToggle={handleRepeatToggle}
      />
    </div>
  );
}
