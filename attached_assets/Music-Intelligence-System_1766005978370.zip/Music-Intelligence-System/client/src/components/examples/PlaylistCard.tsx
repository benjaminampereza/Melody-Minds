import { useState } from "react";
import PlaylistCard from "../PlaylistCard";

export default function PlaylistCardExample() {
  const [playingId, setPlayingId] = useState<string | null>(null);

  // todo: remove mock functionality
  const mockPlaylists = [
    {
      id: "1",
      name: "Chill Vibes",
      description: "Relaxing tracks for your evening wind-down",
      coverImage: "https://i.scdn.co/image/ab67616d0000b273e8b066f70c206551210d902b",
      trackCount: 42,
    },
    {
      id: "2",
      name: "Workout Mix",
      description: "High energy beats to power your training",
      coverImage: "https://i.scdn.co/image/ab67616d0000b2734718e2b124f79258be7bc452",
      trackCount: 65,
    },
    {
      id: "3",
      name: "Focus Flow",
      description: "Instrumental tracks for deep concentration",
      coverImage: "https://i.scdn.co/image/ab67616d0000b2738863bc11d2aa12b54f5aeb36",
      trackCount: 28,
    },
  ];

  return (
    <div className="grid grid-cols-3 gap-4 p-4 bg-background rounded-lg">
      {mockPlaylists.map((playlist) => (
        <PlaylistCard
          key={playlist.id}
          {...playlist}
          isPlaying={playingId === playlist.id}
          onPlay={() => setPlayingId(playlist.id)}
          onPause={() => setPlayingId(null)}
          onClick={() => console.log(`Navigate to playlist ${playlist.id}`)}
        />
      ))}
    </div>
  );
}
