import { useState } from "react";
import PlaylistCurator from "../PlaylistCurator";

export default function PlaylistCuratorExample() {
  const [tracks, setTracks] = useState<any[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);

  // todo: remove mock functionality
  const mockTracks = [
    {
      id: "c1",
      title: "Blinding Lights",
      artist: "The Weeknd",
      albumArt: "https://i.scdn.co/image/ab67616d0000b2738863bc11d2aa12b54f5aeb36",
      tempo: 171,
      energy: 0.8,
      key: "F# Major",
    },
    {
      id: "c2",
      title: "Take On Me",
      artist: "a-ha",
      albumArt: "https://i.scdn.co/image/ab67616d0000b273e8b066f70c206551210d902b",
      tempo: 169,
      energy: 0.85,
      key: "A Major",
    },
    {
      id: "c3",
      title: "Midnight City",
      artist: "M83",
      albumArt: "https://i.scdn.co/image/ab67616d0000b2734718e2b124f79258be7bc452",
      tempo: 105,
      energy: 0.72,
      key: "A Minor",
    },
  ];

  const handleGenerate = (prompt: string) => {
    setIsGenerating(true);
    console.log("Generating playlist for:", prompt);
    setTimeout(() => {
      setTracks(mockTracks);
      setIsGenerating(false);
    }, 2000);
  };

  return (
    <div className="max-w-lg p-4 bg-background rounded-lg">
      <PlaylistCurator
        tracks={tracks}
        isGenerating={isGenerating}
        flowScore={0.87}
        onGenerateFromPrompt={handleGenerate}
        onOptimizeOrder={() => console.log("Optimizing order")}
        onRemoveTrack={(id) => setTracks(tracks.filter((t) => t.id !== id))}
        onSavePlaylist={() => console.log("Saving playlist")}
      />
    </div>
  );
}
