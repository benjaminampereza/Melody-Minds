import { useState } from "react";
import RecommendationEngine from "../RecommendationEngine";

export default function RecommendationEngineExample() {
  const [isLoading, setIsLoading] = useState(false);
  const [recommendations, setRecommendations] = useState<any[]>([]);

  // todo: remove mock functionality
  const mockRecommendations = [
    {
      id: "r1",
      title: "Electric Feel",
      artist: "MGMT",
      albumArt: "https://i.scdn.co/image/ab67616d0000b273e8b066f70c206551210d902b",
      matchScore: 0.94,
      reason: "High energy with similar tempo",
    },
    {
      id: "r2",
      title: "Midnight City",
      artist: "M83",
      albumArt: "https://i.scdn.co/image/ab67616d0000b2734718e2b124f79258be7bc452",
      matchScore: 0.89,
      reason: "Matching synth-heavy production",
    },
    {
      id: "r3",
      title: "Take On Me",
      artist: "a-ha",
      albumArt: "https://i.scdn.co/image/ab67616d0000b2738863bc11d2aa12b54f5aeb36",
      matchScore: 0.85,
      reason: "Classic 80s synthwave energy",
    },
  ];

  const handleGenerate = () => {
    setIsLoading(true);
    setTimeout(() => {
      setRecommendations(mockRecommendations);
      setIsLoading(false);
    }, 1500);
  };

  return (
    <div className="max-w-md p-4 bg-background rounded-lg">
      <RecommendationEngine
        recommendations={recommendations}
        isLoading={isLoading}
        onGenerateRecommendations={handleGenerate}
        onAddToPlaylist={(id) => console.log(`Added ${id} to playlist`)}
      />
    </div>
  );
}
