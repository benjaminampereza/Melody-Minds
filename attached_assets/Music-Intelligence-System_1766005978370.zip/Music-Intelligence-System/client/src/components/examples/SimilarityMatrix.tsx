import SimilarityMatrix from "../SimilarityMatrix";

export default function SimilarityMatrixExample() {
  // todo: remove mock functionality
  const mockTracks = [
    { id: "1", title: "Blinding Lights", artist: "The Weeknd" },
    { id: "2", title: "Save Your Tears", artist: "The Weeknd" },
    { id: "3", title: "Take On Me", artist: "a-ha" },
    { id: "4", title: "Midnight City", artist: "M83" },
    { id: "5", title: "Electric Feel", artist: "MGMT" },
    { id: "6", title: "Starboy", artist: "The Weeknd" },
  ];

  const mockMatrix = [
    [1.0, 0.85, 0.72, 0.68, 0.61, 0.89],
    [0.85, 1.0, 0.65, 0.58, 0.52, 0.82],
    [0.72, 0.65, 1.0, 0.78, 0.74, 0.69],
    [0.68, 0.58, 0.78, 1.0, 0.81, 0.55],
    [0.61, 0.52, 0.74, 0.81, 1.0, 0.48],
    [0.89, 0.82, 0.69, 0.55, 0.48, 1.0],
  ];

  return (
    <div className="max-w-lg p-4 bg-background rounded-lg">
      <SimilarityMatrix tracks={mockTracks} matrix={mockMatrix} />
    </div>
  );
}
