import { useState } from "react";
import SmartSearch from "../SmartSearch";

export default function SmartSearchExample() {
  const [results, setResults] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  // todo: remove mock functionality
  const mockRecentSearches = ["chill vibes", "workout playlist", "The Weeknd"];
  const mockSuggestions = ["happy summer songs", "focus music", "90s nostalgia"];

  const mockResults = [
    {
      id: "1",
      type: "track" as const,
      title: "Blinding Lights",
      subtitle: "The Weeknd",
      image: "https://i.scdn.co/image/ab67616d0000b2738863bc11d2aa12b54f5aeb36",
    },
    {
      id: "2",
      type: "artist" as const,
      title: "The Weeknd",
      subtitle: "Artist",
      image: "https://i.scdn.co/image/ab67616d0000b2738863bc11d2aa12b54f5aeb36",
    },
    {
      id: "3",
      type: "album" as const,
      title: "After Hours",
      subtitle: "The Weeknd - 2020",
      image: "https://i.scdn.co/image/ab67616d0000b2738863bc11d2aa12b54f5aeb36",
    },
  ];

  const handleSearch = (query: string) => {
    setIsLoading(true);
    setTimeout(() => {
      setResults(mockResults);
      setIsLoading(false);
    }, 500);
  };

  return (
    <div className="p-6 bg-background rounded-lg min-h-[300px]">
      <SmartSearch
        recentSearches={mockRecentSearches}
        suggestions={mockSuggestions}
        results={results}
        isLoading={isLoading}
        onSearch={handleSearch}
        onResultClick={(r) => console.log("Clicked:", r)}
        onClearRecent={() => console.log("Cleared recent")}
      />
    </div>
  );
}
