import TemporalAnalysis from "../TemporalAnalysis";

export default function TemporalAnalysisExample() {
  // todo: remove mock functionality
  const mockData = {
    morning: { tracks: 145, topGenre: "Pop", avgEnergy: 0.65 },
    afternoon: { tracks: 234, topGenre: "Hip-Hop", avgEnergy: 0.78 },
    evening: { tracks: 312, topGenre: "Electronic", avgEnergy: 0.82 },
    night: { tracks: 189, topGenre: "R&B", avgEnergy: 0.45 },
  };

  return (
    <div className="max-w-md p-4 bg-background rounded-lg">
      <TemporalAnalysis data={mockData} />
    </div>
  );
}
