import TrackAnalysisPanel from "../TrackAnalysisPanel";

export default function TrackAnalysisPanelExample() {
  // todo: remove mock functionality
  const mockFeatures = {
    acousticness: 0.15,
    danceability: 0.51,
    energy: 0.8,
    instrumentalness: 0.02,
    liveness: 0.09,
    speechiness: 0.06,
    valence: 0.34,
    tempo: 171,
    key: "F#",
    mode: "Major",
    timeSignature: "4/4",
    loudness: -5.93,
    duration: 200,
  };

  return (
    <div className="max-w-sm p-4 bg-background rounded-lg">
      <TrackAnalysisPanel
        trackTitle="Blinding Lights"
        artistName="The Weeknd"
        albumArt="https://i.scdn.co/image/ab67616d0000b2738863bc11d2aa12b54f5aeb36"
        features={mockFeatures}
      />
    </div>
  );
}
