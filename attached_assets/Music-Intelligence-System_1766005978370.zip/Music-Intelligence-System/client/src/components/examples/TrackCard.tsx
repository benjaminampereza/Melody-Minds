import { useState } from "react";
import TrackCard from "../TrackCard";

export default function TrackCardExample() {
  const [playingId, setPlayingId] = useState<string | null>(null);

  // todo: remove mock functionality
  const mockTracks = [
    {
      id: "1",
      title: "Blinding Lights",
      artist: "The Weeknd",
      album: "After Hours",
      albumArt: "https://i.scdn.co/image/ab67616d0000b2738863bc11d2aa12b54f5aeb36",
      duration: "3:20",
      features: { energy: 0.8, danceability: 0.51, valence: 0.34, tempo: 171 },
    },
    {
      id: "2",
      title: "Save Your Tears",
      artist: "The Weeknd",
      album: "After Hours",
      albumArt: "https://i.scdn.co/image/ab67616d0000b2738863bc11d2aa12b54f5aeb36",
      duration: "3:35",
      features: { energy: 0.65, danceability: 0.68, valence: 0.56, tempo: 118 },
    },
    {
      id: "3",
      title: "Starboy",
      artist: "The Weeknd ft. Daft Punk",
      album: "Starboy",
      albumArt: "https://i.scdn.co/image/ab67616d0000b2734718e2b124f79258be7bc452",
      duration: "3:50",
      features: { energy: 0.59, danceability: 0.68, valence: 0.49, tempo: 186 },
    },
  ];

  return (
    <div className="space-y-1 p-4 bg-background rounded-lg">
      {mockTracks.map((track) => (
        <TrackCard
          key={track.id}
          {...track}
          showFeatures
          isPlaying={playingId === track.id}
          onPlay={() => setPlayingId(track.id)}
          onPause={() => setPlayingId(null)}
        />
      ))}
    </div>
  );
}
