import { useState } from "react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import PlaylistCurator from "@/components/PlaylistCurator";
import SimilarityMatrix from "@/components/SimilarityMatrix";
import AudioAnalysisRadar from "@/components/AudioAnalysisRadar";
import { Wand2, GitCompare, BarChart3 } from "lucide-react";

// todo: remove mock functionality
const mockTracks = [
  {
    id: "c1",
    title: "Blinding Lights",
    artist: "The Weeknd",
    albumArt: "https://i.scdn.co/image/ab67616d0000b2738863bc11d2aa12b54f5aeb36",
    tempo: 171,
    energy: 0.8,
    key: "F# Major",
  },
  {
    id: "c2",
    title: "Take On Me",
    artist: "a-ha",
    albumArt: "https://i.scdn.co/image/ab67616d0000b273e8b066f70c206551210d902b",
    tempo: 169,
    energy: 0.85,
    key: "A Major",
  },
  {
    id: "c3",
    title: "Midnight City",
    artist: "M83",
    albumArt: "https://i.scdn.co/image/ab67616d0000b2734718e2b124f79258be7bc452",
    tempo: 105,
    energy: 0.72,
    key: "A Minor",
  },
  {
    id: "c4",
    title: "Electric Feel",
    artist: "MGMT",
    albumArt: "https://i.scdn.co/image/ab67616d0000b273e8b066f70c206551210d902b",
    tempo: 102,
    energy: 0.76,
    key: "E Minor",
  },
  {
    id: "c5",
    title: "Starboy",
    artist: "The Weeknd",
    albumArt: "https://i.scdn.co/image/ab67616d0000b2734718e2b124f79258be7bc452",
    tempo: 186,
    energy: 0.59,
    key: "D Minor",
  },
];

const mockSimilarityTracks = [
  { id: "1", title: "Blinding Lights", artist: "The Weeknd" },
  { id: "2", title: "Save Your Tears", artist: "The Weeknd" },
  { id: "3", title: "Take On Me", artist: "a-ha" },
  { id: "4", title: "Midnight City", artist: "M83" },
  { id: "5", title: "Electric Feel", artist: "MGMT" },
  { id: "6", title: "Starboy", artist: "The Weeknd" },
];

const mockMatrix = [
  [1.0, 0.85, 0.72, 0.68, 0.61, 0.89],
  [0.85, 1.0, 0.65, 0.58, 0.52, 0.82],
  [0.72, 0.65, 1.0, 0.78, 0.74, 0.69],
  [0.68, 0.58, 0.78, 1.0, 0.81, 0.55],
  [0.61, 0.52, 0.74, 0.81, 1.0, 0.48],
  [0.89, 0.82, 0.69, 0.55, 0.48, 1.0],
];

export default function Curator() {
  const [tracks, setTracks] = useState<typeof mockTracks>([]);
  const [isGenerating, setIsGenerating] = useState(false);

  const handleGenerate = (prompt: string) => {
    setIsGenerating(true);
    console.log("Generating playlist for:", prompt);
    setTimeout(() => {
      setTracks(mockTracks);
      setIsGenerating(false);
    }, 2000);
  };

  const averageFeatures = tracks.length > 0
    ? {
        acousticness: 0.2,
        danceability: 0.65,
        energy: tracks.reduce((sum, t) => sum + t.energy, 0) / tracks.length,
        instrumentalness: 0.05,
        liveness: 0.15,
        speechiness: 0.08,
        valence: 0.55,
      }
    : null;

  return (
    <div className="h-full overflow-hidden">
      <ScrollArea className="h-full">
        <div className="p-6 pb-28 space-y-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-md bg-primary/10 flex items-center justify-center">
              <Wand2 className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">Smart Curator</h1>
              <p className="text-sm text-muted-foreground">
                AI-powered playlist generation with flow optimization
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <PlaylistCurator
              tracks={tracks}
              isGenerating={isGenerating}
              flowScore={0.87}
              onGenerateFromPrompt={handleGenerate}
              onOptimizeOrder={() => console.log("Optimizing order")}
              onRemoveTrack={(id) => setTracks(tracks.filter((t) => t.id !== id))}
              onSavePlaylist={() => console.log("Saving playlist")}
            />

            <div className="space-y-6">
              {averageFeatures && (
                <Card className="bg-card">
                  <CardHeader className="pb-2">
                    <CardTitle className="flex items-center gap-2 text-lg">
                      <BarChart3 className="w-5 h-5 text-primary" />
                      Playlist Profile
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="flex justify-center">
                    <AudioAnalysisRadar features={averageFeatures} size={220} />
                  </CardContent>
                </Card>
              )}

              <SimilarityMatrix tracks={mockSimilarityTracks} matrix={mockMatrix} />
            </div>
          </div>
        </div>
      </ScrollArea>
    </div>
  );
}
