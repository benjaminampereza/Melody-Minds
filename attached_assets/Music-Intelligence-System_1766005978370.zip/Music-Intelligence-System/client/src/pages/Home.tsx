import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import TrackCard from "@/components/TrackCard";
import PlaylistCard from "@/components/PlaylistCard";
import AudioAnalysisRadar from "@/components/AudioAnalysisRadar";
import RecommendationEngine from "@/components/RecommendationEngine";
import MoodAnalyzer from "@/components/MoodAnalyzer";
import SmartSearch from "@/components/SmartSearch";
import TemporalAnalysis from "@/components/TemporalAnalysis";
import TrackAnalysisPanel from "@/components/TrackAnalysisPanel";
import {
  Play,
  TrendingUp,
  Sparkles,
  Clock,
  Music2,
  BarChart3,
  ChevronRight,
} from "lucide-react";

// todo: remove mock functionality
const mockCurrentTrack = {
  id: "current",
  title: "Blinding Lights",
  artist: "The Weeknd",
  album: "After Hours",
  albumArt: "https://i.scdn.co/image/ab67616d0000b2738863bc11d2aa12b54f5aeb36",
  duration: "3:20",
  features: {
    acousticness: 0.15,
    danceability: 0.51,
    energy: 0.8,
    instrumentalness: 0.02,
    liveness: 0.09,
    speechiness: 0.06,
    valence: 0.34,
    tempo: 171,
    key: "F#",
    mode: "Major",
    timeSignature: "4/4",
    loudness: -5.93,
    duration: 200,
  },
};

const mockRecentTracks = [
  {
    id: "1",
    title: "Blinding Lights",
    artist: "The Weeknd",
    album: "After Hours",
    albumArt: "https://i.scdn.co/image/ab67616d0000b2738863bc11d2aa12b54f5aeb36",
    duration: "3:20",
    features: { energy: 0.8, danceability: 0.51, valence: 0.34, tempo: 171 },
  },
  {
    id: "2",
    title: "Save Your Tears",
    artist: "The Weeknd",
    album: "After Hours",
    albumArt: "https://i.scdn.co/image/ab67616d0000b2738863bc11d2aa12b54f5aeb36",
    duration: "3:35",
    features: { energy: 0.65, danceability: 0.68, valence: 0.56, tempo: 118 },
  },
  {
    id: "3",
    title: "Take On Me",
    artist: "a-ha",
    album: "Hunting High and Low",
    albumArt: "https://i.scdn.co/image/ab67616d0000b273e8b066f70c206551210d902b",
    duration: "3:46",
    features: { energy: 0.85, danceability: 0.62, valence: 0.78, tempo: 169 },
  },
  {
    id: "4",
    title: "Midnight City",
    artist: "M83",
    album: "Hurry Up, We're Dreaming",
    albumArt: "https://i.scdn.co/image/ab67616d0000b2734718e2b124f79258be7bc452",
    duration: "4:03",
    features: { energy: 0.72, danceability: 0.55, valence: 0.65, tempo: 105 },
  },
  {
    id: "5",
    title: "Electric Feel",
    artist: "MGMT",
    album: "Oracular Spectacular",
    albumArt: "https://i.scdn.co/image/ab67616d0000b273e8b066f70c206551210d902b",
    duration: "3:49",
    features: { energy: 0.76, danceability: 0.75, valence: 0.71, tempo: 102 },
  },
];

const mockPlaylists = [
  {
    id: "1",
    name: "Chill Vibes",
    description: "Relaxing tracks for your evening wind-down",
    coverImage: "https://i.scdn.co/image/ab67616d0000b273e8b066f70c206551210d902b",
    trackCount: 42,
  },
  {
    id: "2",
    name: "Workout Mix",
    description: "High energy beats to power your training",
    coverImage: "https://i.scdn.co/image/ab67616d0000b2734718e2b124f79258be7bc452",
    trackCount: 65,
  },
  {
    id: "3",
    name: "Focus Flow",
    description: "Instrumental tracks for deep concentration",
    coverImage: "https://i.scdn.co/image/ab67616d0000b2738863bc11d2aa12b54f5aeb36",
    trackCount: 28,
  },
  {
    id: "4",
    name: "Discover Weekly",
    description: "Your personalized mix of new discoveries",
    coverImage: "https://i.scdn.co/image/ab67616d0000b273e8b066f70c206551210d902b",
    trackCount: 30,
  },
];

const mockTemporalData = {
  morning: { tracks: 145, topGenre: "Pop", avgEnergy: 0.65 },
  afternoon: { tracks: 234, topGenre: "Hip-Hop", avgEnergy: 0.78 },
  evening: { tracks: 312, topGenre: "Electronic", avgEnergy: 0.82 },
  night: { tracks: 189, topGenre: "R&B", avgEnergy: 0.45 },
};

const mockMood = {
  valence: 0.75,
  energy: 0.82,
  danceability: 0.68,
  acousticness: 0.15,
};

export default function Home() {
  const [playingTrackId, setPlayingTrackId] = useState<string | null>("1");
  const [playingPlaylistId, setPlayingPlaylistId] = useState<string | null>(null);
  const [searchResults, setSearchResults] = useState<any[]>([]);

  const handleSearch = (query: string) => {
    console.log("Searching for:", query);
    setSearchResults([
      {
        id: "s1",
        type: "track",
        title: "Blinding Lights",
        subtitle: "The Weeknd",
        image: mockCurrentTrack.albumArt,
      },
    ]);
  };

  return (
    <div className="h-full overflow-hidden">
      <ScrollArea className="h-full">
        <div className="p-6 pb-28 space-y-8">
          <div
            className="relative h-64 rounded-lg overflow-hidden"
            style={{
              backgroundImage: `url(${mockCurrentTrack.albumArt})`,
              backgroundSize: "cover",
              backgroundPosition: "center",
            }}
          >
            <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-transparent" />
            <div className="absolute inset-0 flex items-end p-6">
              <div className="flex items-end gap-6 w-full">
                <img
                  src={mockCurrentTrack.albumArt}
                  alt={mockCurrentTrack.title}
                  className="w-32 h-32 rounded-lg shadow-2xl"
                  data-testid="img-hero-album"
                />
                <div className="flex-1">
                  <Badge variant="secondary" className="mb-2">
                    <Music2 className="w-3 h-3 mr-1" />
                    Now Playing
                  </Badge>
                  <h1
                    className="text-3xl font-bold mb-1"
                    data-testid="text-hero-title"
                  >
                    {mockCurrentTrack.title}
                  </h1>
                  <p className="text-muted-foreground">{mockCurrentTrack.artist}</p>
                </div>
                <div className="hidden lg:block">
                  <AudioAnalysisRadar
                    features={{
                      acousticness: mockCurrentTrack.features.acousticness,
                      danceability: mockCurrentTrack.features.danceability,
                      energy: mockCurrentTrack.features.energy,
                      instrumentalness: mockCurrentTrack.features.instrumentalness,
                      liveness: mockCurrentTrack.features.liveness,
                      speechiness: mockCurrentTrack.features.speechiness,
                      valence: mockCurrentTrack.features.valence,
                    }}
                    size={140}
                    showLabels={false}
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="flex justify-center">
            <SmartSearch
              recentSearches={["chill vibes", "workout playlist", "The Weeknd"]}
              suggestions={["happy summer songs", "focus music"]}
              results={searchResults}
              onSearch={handleSearch}
              onResultClick={(r) => console.log("Clicked result:", r)}
              onClearRecent={() => console.log("Clear recent")}
            />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-6">
              <Card className="bg-card">
                <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Clock className="w-5 h-5 text-primary" />
                    Recently Played
                  </CardTitle>
                  <Button variant="ghost" size="sm" data-testid="button-see-all-recent">
                    See All
                    <ChevronRight className="w-4 h-4 ml-1" />
                  </Button>
                </CardHeader>
                <CardContent>
                  <div className="space-y-1">
                    {mockRecentTracks.map((track) => (
                      <TrackCard
                        key={track.id}
                        {...track}
                        showFeatures
                        isPlaying={playingTrackId === track.id}
                        onPlay={() => setPlayingTrackId(track.id)}
                        onPause={() => setPlayingTrackId(null)}
                      />
                    ))}
                  </div>
                </CardContent>
              </Card>

              <div>
                <div className="flex items-center justify-between gap-2 mb-4">
                  <h2 className="text-xl font-bold flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-primary" />
                    Your Playlists
                  </h2>
                  <Button variant="ghost" size="sm" data-testid="button-see-all-playlists">
                    See All
                    <ChevronRight className="w-4 h-4 ml-1" />
                  </Button>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {mockPlaylists.map((playlist) => (
                    <PlaylistCard
                      key={playlist.id}
                      {...playlist}
                      isPlaying={playingPlaylistId === playlist.id}
                      onPlay={() => setPlayingPlaylistId(playlist.id)}
                      onPause={() => setPlayingPlaylistId(null)}
                      onClick={() => console.log("Navigate to playlist", playlist.id)}
                    />
                  ))}
                </div>
              </div>
            </div>

            <div className="space-y-6">
              <TrackAnalysisPanel
                trackTitle={mockCurrentTrack.title}
                artistName={mockCurrentTrack.artist}
                albumArt={mockCurrentTrack.albumArt}
                features={mockCurrentTrack.features}
              />

              <MoodAnalyzer
                trackTitle={mockCurrentTrack.title}
                artistName={mockCurrentTrack.artist}
                mood={mockMood}
              />

              <TemporalAnalysis data={mockTemporalData} />
            </div>
          </div>

          <div>
            <div className="flex items-center gap-2 mb-4">
              <Sparkles className="w-5 h-5 text-primary" />
              <h2 className="text-xl font-bold">AI Intelligence Hub</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <RecommendationEngine
                onGenerateRecommendations={(params) =>
                  console.log("Generate with params:", params)
                }
                onAddToPlaylist={(id) => console.log("Add to playlist:", id)}
              />
              <Card className="bg-card">
                <CardHeader className="pb-2">
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <BarChart3 className="w-5 h-5 text-primary" />
                    Your Music DNA
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-center mb-4">
                    <AudioAnalysisRadar
                      features={{
                        acousticness: 0.25,
                        danceability: 0.72,
                        energy: 0.78,
                        instrumentalness: 0.08,
                        liveness: 0.18,
                        speechiness: 0.12,
                        valence: 0.65,
                      }}
                      size={200}
                    />
                  </div>
                  <p className="text-sm text-center text-muted-foreground">
                    Based on your last 50 played tracks, your music profile shows a
                    preference for high-energy, danceable tracks with positive vibes.
                  </p>
                  <div className="flex flex-wrap justify-center gap-2 mt-4">
                    <Badge variant="secondary">Electronic</Badge>
                    <Badge variant="secondary">Pop</Badge>
                    <Badge variant="secondary">Synth</Badge>
                    <Badge variant="secondary">80s</Badge>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </ScrollArea>
    </div>
  );
}
