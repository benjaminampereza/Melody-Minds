import { useState } from "react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import TrackCard from "@/components/TrackCard";
import PlaylistCard from "@/components/PlaylistCard";
import { Library as LibraryIcon, Search, Plus, Music, ListMusic, User, Grid, List } from "lucide-react";

// todo: remove mock functionality
const mockTracks = [
  {
    id: "l1",
    title: "Blinding Lights",
    artist: "The Weeknd",
    album: "After Hours",
    albumArt: "https://i.scdn.co/image/ab67616d0000b2738863bc11d2aa12b54f5aeb36",
    duration: "3:20",
    features: { energy: 0.8, danceability: 0.51, valence: 0.34, tempo: 171 },
  },
  {
    id: "l2",
    title: "Save Your Tears",
    artist: "The Weeknd",
    album: "After Hours",
    albumArt: "https://i.scdn.co/image/ab67616d0000b2738863bc11d2aa12b54f5aeb36",
    duration: "3:35",
    features: { energy: 0.65, danceability: 0.68, valence: 0.56, tempo: 118 },
  },
  {
    id: "l3",
    title: "Take On Me",
    artist: "a-ha",
    album: "Hunting High and Low",
    albumArt: "https://i.scdn.co/image/ab67616d0000b273e8b066f70c206551210d902b",
    duration: "3:46",
    features: { energy: 0.85, danceability: 0.62, valence: 0.78, tempo: 169 },
  },
  {
    id: "l4",
    title: "Midnight City",
    artist: "M83",
    album: "Hurry Up, We're Dreaming",
    albumArt: "https://i.scdn.co/image/ab67616d0000b2734718e2b124f79258be7bc452",
    duration: "4:03",
    features: { energy: 0.72, danceability: 0.55, valence: 0.65, tempo: 105 },
  },
  {
    id: "l5",
    title: "Electric Feel",
    artist: "MGMT",
    album: "Oracular Spectacular",
    albumArt: "https://i.scdn.co/image/ab67616d0000b273e8b066f70c206551210d902b",
    duration: "3:49",
    features: { energy: 0.76, danceability: 0.75, valence: 0.71, tempo: 102 },
  },
  {
    id: "l6",
    title: "Starboy",
    artist: "The Weeknd ft. Daft Punk",
    album: "Starboy",
    albumArt: "https://i.scdn.co/image/ab67616d0000b2734718e2b124f79258be7bc452",
    duration: "3:50",
    features: { energy: 0.59, danceability: 0.68, valence: 0.49, tempo: 186 },
  },
];

const mockPlaylists = [
  {
    id: "p1",
    name: "Chill Vibes",
    description: "Relaxing tracks for your evening",
    coverImage: "https://i.scdn.co/image/ab67616d0000b273e8b066f70c206551210d902b",
    trackCount: 42,
  },
  {
    id: "p2",
    name: "Workout Mix",
    description: "High energy beats",
    coverImage: "https://i.scdn.co/image/ab67616d0000b2734718e2b124f79258be7bc452",
    trackCount: 65,
  },
  {
    id: "p3",
    name: "Focus Flow",
    description: "Instrumental tracks",
    coverImage: "https://i.scdn.co/image/ab67616d0000b2738863bc11d2aa12b54f5aeb36",
    trackCount: 28,
  },
  {
    id: "p4",
    name: "Road Trip",
    description: "Songs for the journey",
    coverImage: "https://i.scdn.co/image/ab67616d0000b273e8b066f70c206551210d902b",
    trackCount: 55,
  },
  {
    id: "p5",
    name: "Late Night",
    description: "After midnight vibes",
    coverImage: "https://i.scdn.co/image/ab67616d0000b2734718e2b124f79258be7bc452",
    trackCount: 38,
  },
  {
    id: "p6",
    name: "Throwbacks",
    description: "Nostalgic hits",
    coverImage: "https://i.scdn.co/image/ab67616d0000b2738863bc11d2aa12b54f5aeb36",
    trackCount: 72,
  },
];

const mockArtists = [
  { id: "a1", name: "The Weeknd", image: "https://i.scdn.co/image/ab67616d0000b2738863bc11d2aa12b54f5aeb36", followers: "85.2M" },
  { id: "a2", name: "M83", image: "https://i.scdn.co/image/ab67616d0000b2734718e2b124f79258be7bc452", followers: "4.1M" },
  { id: "a3", name: "MGMT", image: "https://i.scdn.co/image/ab67616d0000b273e8b066f70c206551210d902b", followers: "6.8M" },
  { id: "a4", name: "a-ha", image: "https://i.scdn.co/image/ab67616d0000b273e8b066f70c206551210d902b", followers: "8.2M" },
];

export default function Library() {
  const [playingTrackId, setPlayingTrackId] = useState<string | null>(null);
  const [playingPlaylistId, setPlayingPlaylistId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");

  const filteredTracks = mockTracks.filter(
    (t) =>
      t.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.artist.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredPlaylists = mockPlaylists.filter((p) =>
    p.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="h-full overflow-hidden">
      <ScrollArea className="h-full">
        <div className="p-6 pb-28 space-y-6">
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-md bg-primary/10 flex items-center justify-center">
                <LibraryIcon className="w-5 h-5 text-primary" />
              </div>
              <div>
                <h1 className="text-2xl font-bold">Your Library</h1>
                <p className="text-sm text-muted-foreground">
                  All your saved music in one place
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Search library..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9 w-64"
                  data-testid="input-library-search"
                />
              </div>
              <Button size="icon" variant="outline" data-testid="button-create-playlist">
                <Plus className="w-4 h-4" />
              </Button>
            </div>
          </div>

          <Tabs defaultValue="playlists" className="w-full">
            <div className="flex items-center justify-between gap-4 mb-4">
              <TabsList>
                <TabsTrigger value="playlists" data-testid="tab-playlists">
                  <ListMusic className="w-4 h-4 mr-2" />
                  Playlists
                </TabsTrigger>
                <TabsTrigger value="tracks" data-testid="tab-tracks">
                  <Music className="w-4 h-4 mr-2" />
                  Tracks
                </TabsTrigger>
                <TabsTrigger value="artists" data-testid="tab-artists">
                  <User className="w-4 h-4 mr-2" />
                  Artists
                </TabsTrigger>
              </TabsList>

              <div className="flex items-center gap-1">
                <Button
                  size="icon"
                  variant={viewMode === "grid" ? "secondary" : "ghost"}
                  onClick={() => setViewMode("grid")}
                  data-testid="button-view-grid"
                >
                  <Grid className="w-4 h-4" />
                </Button>
                <Button
                  size="icon"
                  variant={viewMode === "list" ? "secondary" : "ghost"}
                  onClick={() => setViewMode("list")}
                  data-testid="button-view-list"
                >
                  <List className="w-4 h-4" />
                </Button>
              </div>
            </div>

            <TabsContent value="playlists">
              <div className={viewMode === "grid" ? "grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4" : "space-y-2"}>
                {filteredPlaylists.map((playlist) => (
                  viewMode === "grid" ? (
                    <PlaylistCard
                      key={playlist.id}
                      {...playlist}
                      isPlaying={playingPlaylistId === playlist.id}
                      onPlay={() => setPlayingPlaylistId(playlist.id)}
                      onPause={() => setPlayingPlaylistId(null)}
                      onClick={() => console.log("Navigate to", playlist.id)}
                    />
                  ) : (
                    <div
                      key={playlist.id}
                      className="flex items-center gap-4 p-3 rounded-md hover-elevate cursor-pointer"
                      onClick={() => console.log("Navigate to", playlist.id)}
                    >
                      <img
                        src={playlist.coverImage}
                        alt={playlist.name}
                        className="w-14 h-14 rounded object-cover"
                      />
                      <div className="flex-1 min-w-0">
                        <p className="font-medium truncate">{playlist.name}</p>
                        <p className="text-sm text-muted-foreground truncate">
                          {playlist.description}
                        </p>
                      </div>
                      <span className="text-sm text-muted-foreground">
                        {playlist.trackCount} tracks
                      </span>
                    </div>
                  )
                ))}
              </div>
            </TabsContent>

            <TabsContent value="tracks">
              <div className="space-y-1">
                {filteredTracks.map((track) => (
                  <TrackCard
                    key={track.id}
                    {...track}
                    showFeatures
                    isPlaying={playingTrackId === track.id}
                    onPlay={() => setPlayingTrackId(track.id)}
                    onPause={() => setPlayingTrackId(null)}
                  />
                ))}
              </div>
            </TabsContent>

            <TabsContent value="artists">
              <div className={viewMode === "grid" ? "grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4" : "space-y-2"}>
                {mockArtists.map((artist) => (
                  viewMode === "grid" ? (
                    <div
                      key={artist.id}
                      className="p-4 rounded-md bg-card hover-elevate cursor-pointer text-center"
                      onClick={() => console.log("Navigate to artist", artist.id)}
                    >
                      <img
                        src={artist.image}
                        alt={artist.name}
                        className="w-24 h-24 mx-auto rounded-full object-cover mb-3"
                      />
                      <p className="font-medium truncate">{artist.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {artist.followers} followers
                      </p>
                    </div>
                  ) : (
                    <div
                      key={artist.id}
                      className="flex items-center gap-4 p-3 rounded-md hover-elevate cursor-pointer"
                      onClick={() => console.log("Navigate to artist", artist.id)}
                    >
                      <img
                        src={artist.image}
                        alt={artist.name}
                        className="w-14 h-14 rounded-full object-cover"
                      />
                      <div className="flex-1 min-w-0">
                        <p className="font-medium truncate">{artist.name}</p>
                        <p className="text-sm text-muted-foreground">Artist</p>
                      </div>
                      <span className="text-sm text-muted-foreground">
                        {artist.followers} followers
                      </span>
                    </div>
                  )
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </ScrollArea>
    </div>
  );
}
