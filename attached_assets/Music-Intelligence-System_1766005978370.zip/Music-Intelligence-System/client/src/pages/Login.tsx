import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Headphones, Sparkles, Brain, BarChart3, Music2, Wand2 } from "lucide-react";
import { SiSpotify } from "react-icons/si";

interface LoginProps {
  onLogin?: () => void;
}

const features = [
  {
    icon: Brain,
    title: "AI-Powered Analysis",
    description: "Deep learning algorithms analyze your music taste",
  },
  {
    icon: Sparkles,
    title: "Smart Recommendations",
    description: "Personalized suggestions based on audio features",
  },
  {
    icon: Wand2,
    title: "Playlist Curator",
    description: "Natural language playlist generation",
  },
  {
    icon: BarChart3,
    title: "Music Intelligence",
    description: "Visualize tempo, energy, mood, and more",
  },
];

export default function Login({ onLogin }: LoginProps) {
  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-gradient-to-br from-background via-background to-primary/5">
      <div className="w-full max-w-4xl">
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-primary mb-4">
            <Headphones className="w-8 h-8 text-primary-foreground" />
          </div>
          <h1 className="text-4xl font-bold mb-2">Sonar</h1>
          <p className="text-xl text-muted-foreground">
            Advanced Music Intelligence Platform
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {features.map((feature) => (
            <Card key={feature.title} className="bg-card/50 backdrop-blur">
              <CardContent className="flex items-start gap-4 p-6">
                <div className="w-10 h-10 rounded-md bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <feature.icon className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold mb-1">{feature.title}</h3>
                  <p className="text-sm text-muted-foreground">
                    {feature.description}
                  </p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <Card className="bg-card">
          <CardHeader className="text-center">
            <CardTitle className="flex items-center justify-center gap-2">
              <Music2 className="w-5 h-5 text-primary" />
              Connect Your Music
            </CardTitle>
            <CardDescription>
              Link your Spotify account to unlock personalized music intelligence
            </CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col items-center gap-4">
            <Button
              size="lg"
              className="w-full max-w-sm bg-[#1DB954] hover:bg-[#1ed760] text-white"
              onClick={onLogin}
              data-testid="button-spotify-login"
            >
              <SiSpotify className="w-5 h-5 mr-2" />
              Continue with Spotify
            </Button>
            <div className="flex flex-wrap justify-center gap-2 text-xs text-muted-foreground">
              <Badge variant="outline">Secure OAuth</Badge>
              <Badge variant="outline">Read-only access</Badge>
              <Badge variant="outline">No password stored</Badge>
            </div>
          </CardContent>
        </Card>

        <p className="text-center text-xs text-muted-foreground mt-8">
          By connecting, you agree to our Terms of Service and Privacy Policy.
          <br />
          Sonar uses Spotify's API but is not affiliated with Spotify AB.
        </p>
      </div>
    </div>
  );
}
