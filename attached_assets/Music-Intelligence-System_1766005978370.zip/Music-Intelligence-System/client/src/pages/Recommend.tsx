import { useState } from "react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import RecommendationEngine from "@/components/RecommendationEngine";
import TrackCard from "@/components/TrackCard";
import AudioAnalysisRadar from "@/components/AudioAnalysisRadar";
import { Sparkles, TrendingUp, Zap, Brain } from "lucide-react";

// todo: remove mock functionality
const mockRecommendations = [
  {
    id: "r1",
    title: "Electric Feel",
    artist: "MGMT",
    album: "Oracular Spectacular",
    albumArt: "https://i.scdn.co/image/ab67616d0000b273e8b066f70c206551210d902b",
    matchScore: 0.94,
    reason: "High energy with similar tempo",
    duration: "3:49",
    features: { energy: 0.76, danceability: 0.75, valence: 0.71, tempo: 102 },
  },
  {
    id: "r2",
    title: "Midnight City",
    artist: "M83",
    album: "Hurry Up, We're Dreaming",
    albumArt: "https://i.scdn.co/image/ab67616d0000b2734718e2b124f79258be7bc452",
    matchScore: 0.89,
    reason: "Matching synth-heavy production",
    duration: "4:03",
    features: { energy: 0.72, danceability: 0.55, valence: 0.65, tempo: 105 },
  },
  {
    id: "r3",
    title: "Take On Me",
    artist: "a-ha",
    album: "Hunting High and Low",
    albumArt: "https://i.scdn.co/image/ab67616d0000b273e8b066f70c206551210d902b",
    matchScore: 0.85,
    reason: "Classic 80s synthwave energy",
    duration: "3:46",
    features: { energy: 0.85, danceability: 0.62, valence: 0.78, tempo: 169 },
  },
  {
    id: "r4",
    title: "Somebody That I Used To Know",
    artist: "Gotye",
    album: "Making Mirrors",
    albumArt: "https://i.scdn.co/image/ab67616d0000b2738863bc11d2aa12b54f5aeb36",
    matchScore: 0.82,
    reason: "Similar vocal style and production",
    duration: "4:04",
    features: { energy: 0.51, danceability: 0.64, valence: 0.32, tempo: 129 },
  },
  {
    id: "r5",
    title: "Somebody Else",
    artist: "The 1975",
    album: "I Like It When You Sleep",
    albumArt: "https://i.scdn.co/image/ab67616d0000b2734718e2b124f79258be7bc452",
    matchScore: 0.78,
    reason: "Atmospheric and emotional",
    duration: "5:43",
    features: { energy: 0.45, danceability: 0.58, valence: 0.28, tempo: 104 },
  },
];

const mockTopGenres = [
  { name: "Synth Pop", count: 45 },
  { name: "Electronic", count: 38 },
  { name: "Indie", count: 32 },
  { name: "Alternative", count: 28 },
  { name: "80s", count: 22 },
];

export default function Recommend() {
  const [isLoading, setIsLoading] = useState(false);
  const [recommendations, setRecommendations] = useState<any[]>([]);
  const [playingId, setPlayingId] = useState<string | null>(null);

  const handleGenerateRecommendations = (params: any) => {
    setIsLoading(true);
    console.log("Generating with params:", params);
    setTimeout(() => {
      setRecommendations(mockRecommendations);
      setIsLoading(false);
    }, 1500);
  };

  return (
    <div className="h-full overflow-hidden">
      <ScrollArea className="h-full">
        <div className="p-6 pb-28 space-y-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-md bg-primary/10 flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">AI Recommendations</h1>
              <p className="text-sm text-muted-foreground">
                Discover music tailored to your taste using advanced ML algorithms
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-1">
              <RecommendationEngine
                recommendations={recommendations.slice(0, 3).map((r) => ({
                  id: r.id,
                  title: r.title,
                  artist: r.artist,
                  albumArt: r.albumArt,
                  matchScore: r.matchScore,
                  reason: r.reason,
                }))}
                isLoading={isLoading}
                onGenerateRecommendations={handleGenerateRecommendations}
                onAddToPlaylist={(id) => console.log("Added", id)}
              />
            </div>

            <div className="lg:col-span-2 space-y-6">
              {recommendations.length > 0 && (
                <Card className="bg-card">
                  <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
                    <CardTitle className="flex items-center gap-2 text-lg">
                      <TrendingUp className="w-5 h-5 text-primary" />
                      Recommended Tracks
                    </CardTitle>
                    <Badge variant="secondary">
                      {recommendations.length} tracks
                    </Badge>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-1">
                      {recommendations.map((track) => (
                        <div key={track.id} className="relative">
                          <TrackCard
                            id={track.id}
                            title={track.title}
                            artist={track.artist}
                            album={track.album}
                            albumArt={track.albumArt}
                            duration={track.duration}
                            showFeatures
                            features={track.features}
                            isPlaying={playingId === track.id}
                            onPlay={() => setPlayingId(track.id)}
                            onPause={() => setPlayingId(null)}
                          />
                          <div className="absolute right-24 top-1/2 -translate-y-1/2 hidden md:flex items-center gap-2">
                            <Badge
                              variant="outline"
                              className="text-xs text-primary border-primary"
                            >
                              {Math.round(track.matchScore * 100)}% match
                            </Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="bg-card">
                  <CardHeader className="pb-2">
                    <CardTitle className="flex items-center gap-2 text-lg">
                      <Brain className="w-5 h-5 text-primary" />
                      Your Taste Profile
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="flex justify-center">
                    <AudioAnalysisRadar
                      features={{
                        acousticness: 0.18,
                        danceability: 0.72,
                        energy: 0.78,
                        instrumentalness: 0.12,
                        liveness: 0.15,
                        speechiness: 0.08,
                        valence: 0.65,
                      }}
                      size={180}
                    />
                  </CardContent>
                </Card>

                <Card className="bg-card">
                  <CardHeader className="pb-2">
                    <CardTitle className="flex items-center gap-2 text-lg">
                      <Zap className="w-5 h-5 text-primary" />
                      Top Genres
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {mockTopGenres.map((genre, i) => (
                      <div key={genre.name} className="flex items-center gap-3">
                        <span className="text-sm text-muted-foreground w-4">
                          {i + 1}
                        </span>
                        <div className="flex-1">
                          <div className="flex items-center justify-between gap-2 mb-1">
                            <span className="text-sm font-medium">{genre.name}</span>
                            <span className="text-xs text-muted-foreground">
                              {genre.count} tracks
                            </span>
                          </div>
                          <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                            <div
                              className="h-full bg-primary"
                              style={{
                                width: `${(genre.count / mockTopGenres[0].count) * 100}%`,
                              }}
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </ScrollArea>
    </div>
  );
}
