import { useState } from "react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import SmartSearch from "@/components/SmartSearch";
import TrackCard from "@/components/TrackCard";
import PlaylistCard from "@/components/PlaylistCard";
import { Search as SearchIcon, TrendingUp, Clock, Music, Sparkles } from "lucide-react";

// todo: remove mock functionality
const mockCategories = [
  { id: "1", name: "Electronic", color: "bg-purple-600" },
  { id: "2", name: "Pop", color: "bg-pink-500" },
  { id: "3", name: "Hip-Hop", color: "bg-orange-500" },
  { id: "4", name: "Rock", color: "bg-red-600" },
  { id: "5", name: "Indie", color: "bg-teal-500" },
  { id: "6", name: "R&B", color: "bg-blue-600" },
  { id: "7", name: "Jazz", color: "bg-amber-600" },
  { id: "8", name: "Classical", color: "bg-gray-600" },
];

const mockTrendingTracks = [
  {
    id: "t1",
    title: "Blinding Lights",
    artist: "The Weeknd",
    album: "After Hours",
    albumArt: "https://i.scdn.co/image/ab67616d0000b2738863bc11d2aa12b54f5aeb36",
    duration: "3:20",
    features: { energy: 0.8, danceability: 0.51, valence: 0.34, tempo: 171 },
  },
  {
    id: "t2",
    title: "Levitating",
    artist: "Dua Lipa",
    album: "Future Nostalgia",
    albumArt: "https://i.scdn.co/image/ab67616d0000b273e8b066f70c206551210d902b",
    duration: "3:23",
    features: { energy: 0.83, danceability: 0.7, valence: 0.91, tempo: 103 },
  },
  {
    id: "t3",
    title: "As It Was",
    artist: "Harry Styles",
    album: "Harry's House",
    albumArt: "https://i.scdn.co/image/ab67616d0000b2734718e2b124f79258be7bc452",
    duration: "2:47",
    features: { energy: 0.73, danceability: 0.52, valence: 0.66, tempo: 174 },
  },
];

const mockSearchResults = [
  {
    id: "s1",
    type: "track" as const,
    title: "Blinding Lights",
    subtitle: "The Weeknd",
    image: "https://i.scdn.co/image/ab67616d0000b2738863bc11d2aa12b54f5aeb36",
  },
  {
    id: "s2",
    type: "artist" as const,
    title: "The Weeknd",
    subtitle: "Artist",
    image: "https://i.scdn.co/image/ab67616d0000b2738863bc11d2aa12b54f5aeb36",
  },
  {
    id: "s3",
    type: "album" as const,
    title: "After Hours",
    subtitle: "The Weeknd - 2020",
    image: "https://i.scdn.co/image/ab67616d0000b2738863bc11d2aa12b54f5aeb36",
  },
];

export default function Search() {
  const [results, setResults] = useState<typeof mockSearchResults>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);
  const [playingId, setPlayingId] = useState<string | null>(null);

  const handleSearch = (query: string) => {
    setIsLoading(true);
    setHasSearched(true);
    console.log("Searching:", query);
    setTimeout(() => {
      setResults(mockSearchResults);
      setIsLoading(false);
    }, 500);
  };

  return (
    <div className="h-full overflow-hidden">
      <ScrollArea className="h-full">
        <div className="p-6 pb-28 space-y-8">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-md bg-primary/10 flex items-center justify-center">
              <SearchIcon className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">Search</h1>
              <p className="text-sm text-muted-foreground">
                Find songs, artists, or describe a mood
              </p>
            </div>
          </div>

          <div className="flex justify-center">
            <SmartSearch
              placeholder="What do you want to listen to? Try 'upbeat summer vibes'..."
              recentSearches={["The Weeknd", "chill electronic", "workout mix"]}
              suggestions={["energetic morning songs", "relaxing piano"]}
              results={results}
              isLoading={isLoading}
              onSearch={handleSearch}
              onResultClick={(r) => console.log("Clicked:", r)}
              onClearRecent={() => console.log("Clear recent")}
            />
          </div>

          {!hasSearched && (
            <>
              <div>
                <div className="flex items-center gap-2 mb-4">
                  <Sparkles className="w-5 h-5 text-primary" />
                  <h2 className="text-lg font-bold">Browse Categories</h2>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {mockCategories.map((category) => (
                    <Card
                      key={category.id}
                      className={`${category.color} border-none cursor-pointer hover-elevate`}
                      onClick={() => console.log("Browse category:", category.name)}
                      data-testid={`card-category-${category.id}`}
                    >
                      <CardContent className="p-6">
                        <h3 className="text-lg font-bold text-white">
                          {category.name}
                        </h3>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>

              <div>
                <div className="flex items-center gap-2 mb-4">
                  <TrendingUp className="w-5 h-5 text-primary" />
                  <h2 className="text-lg font-bold">Trending Now</h2>
                </div>
                <div className="space-y-1">
                  {mockTrendingTracks.map((track, index) => (
                    <div key={track.id} className="flex items-center gap-4">
                      <span className="w-6 text-lg font-bold text-muted-foreground text-center">
                        {index + 1}
                      </span>
                      <div className="flex-1">
                        <TrackCard
                          {...track}
                          showFeatures
                          isPlaying={playingId === track.id}
                          onPlay={() => setPlayingId(track.id)}
                          onPause={() => setPlayingId(null)}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <div className="flex items-center gap-2 mb-4">
                  <Music className="w-5 h-5 text-primary" />
                  <h2 className="text-lg font-bold">AI-Suggested Moods</h2>
                </div>
                <div className="flex flex-wrap gap-2">
                  {[
                    "Morning motivation",
                    "Late night coding",
                    "Rainy day reads",
                    "Workout beast mode",
                    "Sunday morning coffee",
                    "Deep focus zone",
                    "Party starter",
                    "Road trip vibes",
                  ].map((mood) => (
                    <Badge
                      key={mood}
                      variant="secondary"
                      className="cursor-pointer text-sm py-2 px-4"
                      onClick={() => handleSearch(mood)}
                      data-testid={`badge-mood-${mood.replace(/\s+/g, "-").toLowerCase()}`}
                    >
                      {mood}
                    </Badge>
                  ))}
                </div>
              </div>
            </>
          )}

          {hasSearched && results.length > 0 && (
            <div className="space-y-4">
              <h2 className="text-lg font-bold">Search Results</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {results.map((result) => (
                  <Card
                    key={result.id}
                    className="bg-card cursor-pointer hover-elevate"
                    onClick={() => console.log("Navigate to:", result)}
                  >
                    <CardContent className="p-4 flex items-center gap-4">
                      <img
                        src={result.image}
                        alt={result.title}
                        className={`w-16 h-16 object-cover ${result.type === "artist" ? "rounded-full" : "rounded-md"}`}
                      />
                      <div className="flex-1 min-w-0">
                        <p className="font-medium truncate">{result.title}</p>
                        <p className="text-sm text-muted-foreground truncate">
                          {result.subtitle}
                        </p>
                        <Badge variant="outline" className="mt-1 capitalize text-xs">
                          {result.type}
                        </Badge>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}
        </div>
      </ScrollArea>
    </div>
  );
}
