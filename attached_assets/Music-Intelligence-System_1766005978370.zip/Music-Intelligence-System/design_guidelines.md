# Music Intelligence Platform - Design Guidelines

## Design Approach
**Reference-Based:** Spotify's interface (primary) + SoundCloud's player design (secondary). Focus on intuitive music controls, clean data visualization dashboards, and immersive audio-first experience.

## Color System
- **Primary:** #1DB954 (Spotify green) - CTAs, active states, progress bars
- **Secondary:** #191414 (deep black) - primary surfaces, cards
- **Background:** #121212 (dark grey) - app background
- **Text:** #FFFFFF (white) - primary text, 0.6 opacity for secondary text
- **Accent:** #535353 (medium grey) - borders, dividers, inactive elements
- **Highlight:** #1ED760 (bright green) - hover states, success indicators

## Typography
- **Font Families:** Circular (primary), Gotham (fallback) via CDN
- **Hierarchy:**
  - Hero/Dashboard Titles: 48px/bold
  - Section Headers: 32px/bold
  - Card Titles: 20px/semibold
  - Body Text: 14px/regular
  - Metadata/Labels: 12px/medium

## Layout System
- **Spacing Units:** Tailwind units of 2, 4, 6, 8, 12, 16, 24
- **Grid System:** Responsive grid with 16px gutters
- **Container Max-width:** 1400px for dashboard, full-width for player
- **Sidebar:** Fixed 240px width (collapsible on mobile)

## Core Components

### Navigation
- **Fixed Sidebar:** Navigation menu with playlists, library sections
- **Top Bar:** Search, user profile, playback status indicator
- **Mobile:** Bottom tab navigation + hamburger menu

### Playback Controls
- **Fixed Bottom Player:** Full-width sticky player bar (80px height)
- **Controls Layout:** Track info (left) | Play/Pause/Skip controls (center) | Volume/Queue (right)
- **Progress Bar:** Full-width with time indicators, draggable seek
- **Album Art:** 56px rounded thumbnail with subtle shadow

### Cards & Content
- **Track Cards:** 64px height, album art (48px) + metadata, hover reveals play button
- **Playlist Cards:** 200px square, cover image, title overlay with glassmorphism
- **Analysis Cards:** Gradient backgrounds showing data visualizations (charts, gauges)
- **Glassmorphism:** backdrop-blur-lg with rgba(25, 20, 20, 0.8) backgrounds

### Data Visualization
- **Feature Graphs:** Radial/spider charts for audio features (green gradients)
- **Waveforms:** Linear gradients (#1DB954 to #1ED760) for visual feedback
- **Progress Indicators:** Circular for track analysis, linear for playlists
- **Statistics Panels:** Grid layout showing tempo, energy, key with large numbers

### Search & Discovery
- **Search Bar:** Prominent with rounded corners, icon prefix, 400px width
- **Results Grid:** 4-column responsive grid (2-col tablet, 1-col mobile)
- **Filters:** Horizontal scrollable chips with active state highlighting

### Dashboard Layout
- **Hero Section:** Full-width gradient banner (300px height) with currently playing track analysis
- **Three-Column Layout:** 
  - Left: Recently played (300px)
  - Center: Recommendations feed (flexible)
  - Right: Analysis panel (360px)
- **Mobile:** Single column stack

## Interaction Patterns
- **Hover States:** Brightness increase, scale(1.02) for cards
- **Active States:** Opacity 0.8, slight scale(0.98)
- **Transitions:** 200ms ease-out for all state changes
- **Loading States:** Skeleton screens with shimmer effect in #535353

## Icons
- **Library:** Heroicons (outline for inactive, solid for active)
- **Size:** 24px for navigation, 20px for buttons, 16px for inline

## Images
- **Album Art:** Use throughout - player, cards, backgrounds with gradient overlays
- **Hero Background:** Blurred album art of currently playing track with dark overlay (opacity 0.4)
- **Playlist Covers:** User-generated or Spotify default covers
- **Artist Images:** Circular crops for artist profiles

## Accessibility
- High contrast maintained (#FFFFFF on #121212)
- Focus indicators using #1ED760 outline (2px)
- Keyboard navigation for all playback controls
- ARIA labels for icon-only buttons

## Responsive Breakpoints
- Desktop: 1024px+ (full layout)
- Tablet: 768px-1023px (2-column)
- Mobile: <768px (single column, bottom player)